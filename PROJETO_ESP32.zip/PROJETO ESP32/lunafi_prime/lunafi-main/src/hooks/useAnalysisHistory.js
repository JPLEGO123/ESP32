import { useCallback, useState } from "react";
import { loadHistory, addAnalysis, clearHistory, getStats } from "@/lib/history/analysisHistory";

// Hook React sobre o histórico persistente de análises.
export function useAnalysisHistory() {
  const [history, setHistory] = useState(() => loadHistory());
  const [stats, setStats] = useState(() => getStats(loadHistory()));

  const refresh = useCallback(() => {
    const h = loadHistory();
    setHistory(h);
    setStats(getStats(h));
  }, []);

  const add = useCallback(
    (payload) => {
      const entry = addAnalysis(payload);
      if (entry) refresh();
      return entry;
    },
    [refresh]
  );

  const clear = useCallback(() => {
    clearHistory();
    refresh();
  }, [refresh]);

  return { history, stats, add, clear, refresh };
}