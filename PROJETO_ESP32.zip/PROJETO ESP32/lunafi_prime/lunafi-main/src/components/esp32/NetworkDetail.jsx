import React from "react";
import { X, Wifi, Radar, Hash, Signal } from "lucide-react";
import { classifySignal, signalPercent } from "@/lib/esp32/quality";

function Row({ icon, label, children }) {
  return (
    <div className="flex items-start gap-3 py-2.5 border-b border-nr-border">
      <div className="text-nr-accent/70 mt-0.5">{icon}</div>
      <div className="flex-1">
        <p className="text-[11px] text-nr-dim/40 uppercase tracking-wide">{label}</p>
        <p className="mt-0.5">{children}</p>
      </div>
    </div>
  );
}

export default function NetworkDetail({ network, onAnalyze, onClose }) {
  const q = classifySignal(network.rssi);
  const pct = signalPercent(network.rssi);
  return (
    <div className="fixed sm:absolute right-0 top-0 bottom-0 w-full sm:w-[360px] bg-nr-bg border-l border-nr-border z-[1000] flex flex-col text-nr-text">
      <div className="flex items-center justify-between px-5 py-4 border-b border-nr-border">
        <h3 className="font-semibold">Detalhes da rede</h3>
        <button onClick={onClose} className="p-2 rounded-lg hover:bg-nr-dim/10 text-nr-dim/50 transition">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-5 space-y-5">
        <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${q.chip}`}>
            <Wifi className={`w-6 h-6 ${q.text}`} />
          </div>
          <div className="min-w-0">
            <h4 className="font-semibold leading-tight truncate">{network.ssid}</h4>
            <p className="text-xs text-nr-dim/40 mt-0.5">Rede detectada pelo ESP32</p>
          </div>
        </div>

        <div className="rounded-xl bg-nr-panel p-4">
          <div className="flex items-end justify-between">
            <div>
              <p className="text-[11px] text-nr-dim/40 uppercase tracking-wide">Intensidade</p>
              <p className="text-3xl font-bold font-mono">
                {network.rssi}
                <span className="text-sm text-nr-dim/50 ml-1">dBm</span>
              </p>
            </div>
            <span className={`px-2 py-1 rounded-lg text-xs font-semibold ${q.chip} ${q.text}`}>{q.label}</span>
          </div>
          <div className="h-1.5 rounded-full bg-nr-border mt-3 overflow-hidden">
            <div className={`h-full rounded-full ${q.bar}`} style={{ width: `${pct}%` }} />
          </div>
        </div>

        <div className="space-y-1 text-sm">
          <Row icon={<Hash className="w-4 h-4" />} label="Canal">
            {network.channel ?? "—"}
          </Row>
          <Row icon={<Signal className="w-4 h-4" />} label="BSSID">
            <span className="font-mono text-xs">{network.bssid || "—"}</span>
          </Row>
        </div>

        <button
          onClick={onAnalyze}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-nr-btn hover:bg-nr-btn/85 text-white text-sm font-medium transition"
        >
          <Radar className="w-4 h-4" /> Analisar rede
        </button>
      </div>
    </div>
  );
}