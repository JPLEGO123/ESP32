import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { X, MapPin, Wifi, Signal, Hash, Gauge, FlaskConical, Cpu } from "lucide-react";
import { qualityByLabel } from "@/lib/esp32/quality";

// Cores de qualidade aplicadas via classes de texto (adaptativas ao tema).

function InfoRow({ icon, label, children }) {
  return (
    <div className="flex items-start gap-3 py-2.5 border-b border-nr-border">
      <div className="text-nr-accent/70 mt-0.5">{icon}</div>
      <div className="flex-1 min-w-0">
        <p className="text-[11px] text-nr-dim/40 uppercase tracking-wide">{label}</p>
        <p className="mt-0.5 break-words">{children}</p>
      </div>
    </div>
  );
}

export default function HistoryDetailModal({ analysis, onClose }) {
  if (!analysis) return null;
  const a = analysis;
  const chartData = a.networks
    .map((n) => ({ name: (n.ssid || "?").slice(0, 10), rssi: n.rssi }))
    .filter((d) => typeof d.rssi === "number");
  const hasChart = chartData.length >= 2;

  return (
    <div className="fixed inset-0 z-[1300] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-2xl max-h-[90vh] rounded-2xl bg-nr-panel border border-nr-border shadow-2xl flex flex-col text-nr-text"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-nr-border">
          <h3 className="font-semibold flex items-center gap-2">
            <Gauge className="w-4 h-4 text-nr-accent" /> Análise
          </h3>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-nr-dim/10 text-nr-dim/50 transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {/* Resumo */}
          <div className="space-y-1 text-sm">
            <InfoRow icon={<Gauge className="w-4 h-4" />} label="Data">
              {new Date(a.timestamp).toLocaleString("pt-BR")}
            </InfoRow>
            <InfoRow icon={<Wifi className="w-4 h-4" />} label="Redes encontradas">
              {a.networkCount}
            </InfoRow>
            <InfoRow icon={<Signal className="w-4 h-4" />} label="Melhor sinal">
              {a.bestRssi != null ? `${a.bestRssi} dBm` : "Sem dados"}
            </InfoRow>
            <InfoRow icon={<Signal className="w-4 h-4" />} label="Pior sinal">
              {a.worstRssi != null ? `${a.worstRssi} dBm` : "Sem dados"}
            </InfoRow>
            <InfoRow icon={<Gauge className="w-4 h-4" />} label="Qualidade geral">
              <span className={qualityByLabel(a.overallQuality).text}>{a.overallQuality}</span>
            </InfoRow>
            <InfoRow icon={<Cpu className="w-4 h-4" />} label="Tipo de análise">
              <span className={a.mode === "DEMO" ? "text-nr-demo" : "text-nr-accent"}>
                {a.mode === "DEMO" ? "🧪 DEMO" : "📡 ESP32"}
              </span>
            </InfoRow>
            <InfoRow icon={<MapPin className="w-4 h-4" />} label="Localização da análise">
              {a.latitude != null && a.longitude != null
                ? `${a.latitude.toFixed(5)}, ${a.longitude.toFixed(5)}`
                : "Sem dados"}
            </InfoRow>
          </div>

          {/* Gráfico */}
          <div>
            <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <Signal className="w-4 h-4 text-nr-accent" /> Intensidade do sinal
            </h4>
            {hasChart ? (
              <div className="h-48 w-full bg-nr-bg rounded-xl border border-nr-border p-3">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
                    <defs>
                      <linearGradient id="rssiGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#22d3ee" stopOpacity={0.5} />
                        <stop offset="100%" stopColor="#22d3ee" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                    <XAxis dataKey="name" tick={{ fill: "#94a3b8", fontSize: 10 }} stroke="rgba(255,255,255,0.1)" />
                    <YAxis domain={[-95, -30]} tick={{ fill: "#94a3b8", fontSize: 10 }} stroke="rgba(255,255,255,0.1)" />
                    <Tooltip
                      contentStyle={{ background: "#1a2530", border: "1px solid #243441", borderRadius: 8, fontSize: 12 }}
                      labelStyle={{ color: "#cbd5e1" }}
                    />
                    <Area type="monotone" dataKey="rssi" stroke="#22d3ee" strokeWidth={2} fill="url(#rssiGrad)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <p className="text-xs text-nr-dim/50 bg-nr-bg rounded-xl border border-nr-border p-4 text-center">
                Dados insuficientes para gerar o gráfico.
              </p>
            )}
          </div>

          {/* Redes encontradas */}
          <div>
            <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <Wifi className="w-4 h-4 text-nr-accent" /> Redes encontradas
            </h4>
            <div className="space-y-2">
              {a.networks.map((n, i) => (
                <div key={n.id || i} className="bg-nr-bg rounded-xl border border-nr-border p-3 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-medium truncate">{n.ssid}</span>
                    <span className="font-mono flex-shrink-0">{n.rssi} dBm</span>
                  </div>
                  <div className="flex items-center justify-between gap-2 mt-1.5">
                    <span className={`px-1.5 py-0.5 rounded font-medium ${qualityByLabel(n.quality).text}`}>
                      {n.quality}
                    </span>
                    <span className="text-nr-dim/50 flex items-center gap-1">
                      <Hash className="w-3 h-3" /> Canal {n.channel ?? "—"}
                    </span>
                  </div>
                  {n.bssid && <p className="text-[10px] text-nr-dim/40 mt-1.5 font-mono break-all">{n.bssid}</p>}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}