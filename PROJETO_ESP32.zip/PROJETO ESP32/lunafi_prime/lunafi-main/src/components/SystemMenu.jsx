import React from "react";
import { X, Gauge, Hash, Tag, Sun, Moon } from "lucide-react";

export default function SystemMenu({ open, onClose, config, onChange }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[1200] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="relative w-[420px] max-w-[92vw] max-h-[90vh] overflow-y-auto rounded-2xl bg-nr-panel border border-nr-border shadow-2xl p-6 text-nr-text"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-semibold flex items-center gap-2">
            <Gauge className="w-4 h-4 text-nr-accent" /> Sistema — Configurações
          </h3>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-nr-dim/10 text-nr-dim/60 transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-5">
          {/* Theme */}
          <div>
            <label className="flex items-center gap-2 text-sm text-nr-dim/80 mb-2">
              <Sun className="w-4 h-4 text-nr-accent" /> Tema do aplicativo
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                onClick={() => onChange({ ...config, theme: "dark" })}
                className={`flex items-center justify-center gap-2 h-11 rounded-lg border text-sm font-medium transition ${
                  config.theme === "dark"
                    ? "bg-nr-accent/15 border-nr-accent text-nr-accent"
                    : "bg-nr-bg border-nr-border text-nr-dim/70 hover:border-nr-dim/40"
                }`}
              >
                <Moon className="w-4 h-4" /> Escuro
              </button>
              <button
                onClick={() => onChange({ ...config, theme: "light" })}
                className={`flex items-center justify-center gap-2 h-11 rounded-lg border text-sm font-medium transition ${
                  config.theme === "light"
                    ? "bg-nr-accent/15 border-nr-accent text-nr-accent"
                    : "bg-nr-bg border-nr-border text-nr-dim/70 hover:border-nr-dim/40"
                }`}
              >
                <Sun className="w-4 h-4" /> Claro
              </button>
            </div>
          </div>

          {/* Radius */}
          <div>
            <label className="flex items-center justify-between text-sm text-nr-dim/80 mb-2">
              <span className="flex items-center gap-2"><Gauge className="w-4 h-4 text-nr-accent" /> Raio de detecção</span>
              <span className="text-nr-accent font-mono">
                {config.radius >= 1000 ? `${(config.radius / 1000).toFixed(1)} km` : `${config.radius} m`}
              </span>
            </label>
            <input
              type="range"
              min={10}
              max={1000}
              step={10}
              value={config.radius}
              onChange={(e) => onChange({ ...config, radius: Number(e.target.value) })}
              className="w-full accent-nr-accent"
            />
            <div className="flex justify-between text-[10px] text-nr-dim/30 mt-1">
              <span>10 m</span><span>1 km</span>
            </div>
          </div>

          {/* Max results */}
          <div>
            <label className="flex items-center justify-between text-sm text-nr-dim/80 mb-2">
              <span className="flex items-center gap-2"><Hash className="w-4 h-4 text-nr-accent" /> Quantidade a detectar</span>
              <span className="text-nr-accent font-mono">{config.maxResults}</span>
            </label>
            <input
              type="range"
              min={5}
              max={100}
              step={5}
              value={config.maxResults}
              onChange={(e) => onChange({ ...config, maxResults: Number(e.target.value) })}
              className="w-full accent-nr-accent"
            />
            <div className="flex justify-between text-[10px] text-nr-dim/30 mt-1">
              <span>5</span><span>100</span>
            </div>
          </div>

          {/* Name filter */}
          <div>
            <label className="flex items-center gap-2 text-sm text-nr-dim/80 mb-2">
              <Tag className="w-4 h-4 text-nr-accent" /> Filtrar por nome
            </label>
            <input
              type="text"
              value={config.nameFilter}
              placeholder="Ex.: café, library, Starbucks…"
              onChange={(e) => onChange({ ...config, nameFilter: e.target.value })}
              className="w-full bg-nr-bg border border-nr-border rounded-lg px-3 py-2 text-sm placeholder-nr-dim/30 focus:outline-none focus:border-nr-accent transition"
            />
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full mt-6 py-2.5 rounded-lg bg-nr-btn hover:bg-nr-btn/85 text-white text-sm font-medium transition"
        >
          Salvar e aplicar
        </button>
      </div>
    </div>
  );
}