import React from "react";
import { RefreshCw, Bluetooth, Wifi, Power } from "lucide-react";
import NetworkCard from "./NetworkCard";

export default function NetworkList({ networks, selected, onSelect, onAnalyze, onScan, connectionState, demoMode, lastUpdate, radarActive }) {
  const connected = connectionState === "connected" || connectionState === "receiving";
  const empty = networks.length === 0;

  return (
    <div className="flex flex-col h-full bg-nr-bg text-nr-text">
      <div className="flex items-center justify-between px-4 py-3.5 border-b border-nr-border">
        <div>
          <h2 className="text-sm font-semibold flex items-center gap-2">
            Pontos encontrados
            {demoMode && (
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-nr-accent/20 text-nr-accent tracking-wider">DEMO</span>
            )}
          </h2>
          <p className="text-[11px] text-nr-dim/40">
            {connected ? `${networks.length} ${networks.length === 1 ? "rede" : "redes"} no mapa` : "Aguardando ESP32"}
            {lastUpdate ? ` · ${new Date(lastUpdate).toLocaleTimeString("pt-BR")}` : ""}
          </p>
        </div>
        <button
          onClick={onScan}
          disabled={!connected}
          title="Nova varredura (SCAN)"
          className="p-2 rounded-lg hover:bg-nr-dim/10 text-nr-accent disabled:opacity-40 transition"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {empty ? (
          <div className="px-4 py-16 text-center text-nr-dim/40">
            {!connected ? (
              <>
                <Bluetooth className="w-8 h-8 mx-auto mb-3 opacity-40" />
                <p className="text-sm">Aguardando ESP32</p>
                <p className="text-xs mt-1">Conecte o dispositivo para receber as redes.</p>
              </>
            ) : !radarActive ? (
              <>
                <Power className="w-8 h-8 mx-auto mb-3 opacity-40" />
                <p className="text-sm">Radar desligado</p>
                <p className="text-xs mt-1">Ative o radar para visualizar as redes no mapa.</p>
              </>
            ) : (
              <>
                <Wifi className="w-8 h-8 mx-auto mb-3 opacity-40" />
                <p className="text-sm">Nenhuma rede encontrada</p>
                <p className="text-xs mt-1">Toque no botão de scan para nova varredura.</p>
              </>
            )}
          </div>
        ) : (
          networks.map((n) => (
            <NetworkCard
              key={n.id || `${n.ssid}-${n.bssid || ""}`}
              network={n}
              selected={selected?.id === n.id}
              onSelect={() => onSelect(n)}
              onAnalyze={onAnalyze}
            />
          ))
        )}
      </div>
    </div>
  );
}