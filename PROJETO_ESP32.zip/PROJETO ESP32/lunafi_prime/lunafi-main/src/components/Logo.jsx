// Símbolo do LUNAFI — lua crescente preenchida (gradiente ciano→azul) com
// 3 ondas de sinal Wi-Fi emanando da concavidade da lua (sem ponto central).
// O gradiente usa variáveis CSS de tema (--nr-grad-top / --nr-grad-bottom),
// adaptando-se automaticamente entre tema claro e escuro.
export default function Logo({ className = "" }) {
  return (
    <svg
      viewBox="0 0 48 48"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="LUNAFI"
      preserveAspectRatio="xMidYMid meet"
    >
      <defs>
        <linearGradient id="lunafiGrad" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="48" y2="48">
          <stop offset="0%" stopColor="var(--nr-grad-top)" />
          <stop offset="100%" stopColor="var(--nr-grad-bottom)" />
        </linearGradient>
        <mask id="lunafiCrescent">
          <rect width="48" height="48" fill="black" />
          <circle cx="20" cy="24" r="16" fill="white" />
          <circle cx="27" cy="24" r="14" fill="black" />
        </mask>
      </defs>
      {/* Lua crescente preenchida com gradiente (concavidade à direita) */}
      <rect x="0" y="0" width="48" height="48" fill="url(#lunafiGrad)" mask="url(#lunafiCrescent)" />
      {/* 3 ondas Wi-Fi emanando da concavidade da lua */}
      <g stroke="url(#lunafiGrad)" strokeWidth="3" strokeLinecap="round" fill="none">
        <path d="M27.86 19.4 A6 6 0 0 1 27.86 28.6" />
        <path d="M30.43 16.34 A10 10 0 0 1 30.43 31.66" />
        <path d="M33 13.28 A14 14 0 0 1 33 34.72" />
      </g>
    </svg>
  );
}