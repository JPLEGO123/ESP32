import React, { useEffect, useRef } from "react";
import { MapContainer, TileLayer, Marker, Popup, Tooltip, useMap, Circle } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { classifySignal } from "@/lib/esp32/quality";

// SVG de ondas Wi-Fi (sem ponto central) na cor da qualidade.
const svgWifi = (color) =>
  `<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.55a11 11 0 0 1 14 0"/><path d="M8.5 16.1a5 5 0 0 1 7 0"/><path d="M2 8.82a15 15 0 0 1 20 0"/></svg>`;

// Marcador de rede: pequeno, elegante, colorido pela qualidade.
function networkIcon(q, dark) {
  const color = dark ? q.marker : q.markerLight;
  return L.divIcon({
    html: `<div style="position:relative;width:26px;height:26px;">
      <div style="position:absolute;inset:0;border-radius:50%;background:${color}22;border:2px solid ${color};box-shadow:0 0 0 3px ${color}1a,0 0 8px ${color}66;"></div>
      <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:${color};">${svgWifi(color)}</div>
    </div>`,
    className: "",
    iconSize: [26, 26],
    iconAnchor: [13, 13],
  });
}

// Marcador do usuário (distinto das redes).
const userIcon = L.divIcon({
  html: `<div style="width:14px;height:14px;border-radius:50%;background:#00b4d8;border:3px solid #fff;box-shadow:0 0 0 6px rgba(0,180,216,.25),0 0 12px rgba(0,180,216,.6);"></div>`,
  className: "",
  iconSize: [14, 14],
  iconAnchor: [7, 7],
});

// Recalcula o tamanho do mapa sempre que o container muda (resize, breakpoint,
// orientação, abertura/fechamento de painéis) — sem recriar o mapa.
function MapResizer() {
  const map = useMap();

  useEffect(() => {
    // Recalcula apenas o tamanho/viewport — NÃO altera zoom, centro ou marcadores.
    const invalidate = () =>
      requestAnimationFrame(() =>
        map.invalidateSize({ animate: false, pan: false })
      );

    // Após a montagem: garante o tamanho correto quando o layout já foi calculado.
    invalidate();
    const t = setTimeout(invalidate, 250);

    window.addEventListener("resize", invalidate);
    window.addEventListener("orientationchange", invalidate);

    // Detecta mudanças REAIS no container (breakpoint, painéis, reflow do grid/flex),
    // que podem ocorrer sem um evento window.resize.
    let ro;
    if (typeof ResizeObserver !== "undefined") {
      ro = new ResizeObserver(invalidate);
      ro.observe(map.getContainer());
    }

    return () => {
      clearTimeout(t);
      window.removeEventListener("resize", invalidate);
      window.removeEventListener("orientationchange", invalidate);
      if (ro) ro.disconnect();
    };
  }, [map]);

  return null;
}

// Enquadra o mapa na área de busca (círculo do raio). Reenquadra quando o raio muda e, enquanto a
// posição vem do GPS (`followUser`), quando ela melhora. Se o usuário ajusta o marcador na mão,
// não reenquadra (o mapa não "pula" a cada arrasto).
// Pequeno atraso para o container já ter o tamanho final (evita zoom errado em layout em transição).
function FitSearchArea({ center, radius, followUser }) {
  const map = useMap();
  const lastRef = useRef({ radius: null, fitted: false });
  useEffect(() => {
    if (!center) {
      lastRef.current = { radius: null, fitted: false };
      return undefined;
    }
    const radiusChanged = lastRef.current.radius !== radius;
    if (lastRef.current.fitted && !radiusChanged && !followUser) return undefined;
    const t = setTimeout(() => {
      map.invalidateSize({ animate: false, pan: false });
      // Quadrado de lado 2×raio centrado no usuário (cobre todo o círculo de busca).
      const bounds = L.latLng(center[0], center[1]).toBounds(radius * 2);
      map.fitBounds(bounds, { padding: [30, 30], maxZoom: 18, animate: true });
      lastRef.current = { radius, fitted: true };
    }, 300);
    return () => clearTimeout(t);
  }, [center, radius, followUser, map]);
  return null;
}

function Recenter({ center }) {
  const map = useMap();
  useEffect(() => {
    if (center) map.setView(center, map.getZoom(), { animate: true });
  }, [center, map]);
  return null;
}

// Marcador de rede com popup + tooltip. Abre o popup automaticamente quando
// a rede correspondente é selecionada na lista.
function NetworkMarker({ network, selected, onSelect, dark }) {
  const ref = useRef(null);
  useEffect(() => {
    if (selected && ref.current) ref.current.openPopup();
  }, [selected]);
  const q = classifySignal(network.rssi);
  return (
    <Marker
      ref={ref}
      position={[network.latitude, network.longitude]}
      icon={networkIcon(q, dark)}
      eventHandlers={{ click: () => onSelect(network) }}
    >
      <Popup>
        <div className="space-y-1.5 min-w-[170px] text-slate-900">
          <div>
            <div className="text-[10px] uppercase tracking-wide text-slate-400">Nome da rede</div>
            <div className="font-semibold text-sm">{network.ssid}</div>
          </div>
          <div className="flex justify-between text-xs"><span className="text-slate-500">Sinal</span><span className="font-mono">{network.rssi} dBm</span></div>
          <div className="flex justify-between text-xs"><span className="text-slate-500">Qualidade</span><span style={{ color: q.markerLight }} className="font-medium">{q.label}</span></div>
          <div className="flex justify-between text-xs"><span className="text-slate-500">Canal</span><span>{network.channel ?? "—"}</span></div>
          <div className="flex justify-between text-xs gap-2"><span className="text-slate-500">BSSID</span><span className="font-mono text-[10px]">{network.bssid || "—"}</span></div>
          {network.demo && <div className="pt-1 text-[11px] text-cyan-600 font-medium">🧪 DEMO</div>}
        </div>
      </Popup>
      <Tooltip direction="top" offset={[0, -8]} opacity={1}>
        <div className="text-slate-900">
          <div className="font-medium text-xs">{network.ssid}</div>
          <div className="text-[11px] text-slate-500">{network.rssi} dBm · {q.label}</div>
        </div>
      </Tooltip>
    </Marker>
  );
}

export default function WifiMap({
  userPos,
  accuracy = null,
  followUser = true,
  onUserMove,
  networks = [],
  selected,
  onSelect,
  dark,
  radius = 1000,
}) {
  const center = userPos || [-14.235, -51.9253];
  const sel = selected && selected.latitude != null ? [selected.latitude, selected.longitude] : null;
  return (
    <MapContainer center={center} zoom={userPos ? 15 : 4} className="w-full h-full min-w-0 min-h-0 z-0" zoomControl={false}>
      {/* OpenStreetMap: não exige chave de API. O tema escuro é feito por filtro CSS (ver index.css).
          `key` recria a camada quando o tema muda, para a classe ser reaplicada. */}
      <TileLayer
        key={dark ? "tiles-dark" : "tiles-light"}
        url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        className={dark ? "lunafi-tiles-dark" : ""}
        maxZoom={19}
      />
      <MapResizer />
      <FitSearchArea center={userPos} radius={radius} followUser={followUser} />
      <Recenter center={sel || center} />
      {userPos && (
        <>
          <Circle center={userPos} radius={radius} pathOptions={{ color: "#00b4d8", weight: 1, fillColor: "#00b4d8", fillOpacity: 0.08 }} />
          {/* Erro estimado da localização (só quando vem do GPS/aparelho). */}
          {accuracy != null && (
            <Circle
              center={userPos}
              radius={Math.max(accuracy, 1)}
              pathOptions={{ color: "#f59e0b", weight: 1, dashArray: "4 4", fillColor: "#f59e0b", fillOpacity: 0.07 }}
            />
          )}
          {/* Arraste o marcador para ajustar o local exato (útil em computadores sem GPS). */}
          <Marker
            position={userPos}
            icon={userIcon}
            draggable={!!onUserMove}
            zIndexOffset={1000}
            eventHandlers={{
              dragend: (e) => {
                const ll = e.target.getLatLng();
                if (onUserMove) onUserMove([ll.lat, ll.lng]);
              },
            }}
          >
            <Popup>
              Você está aqui 📍
              {onUserMove && (
                <>
                  <br />
                  <span style={{ fontSize: 11, opacity: 0.7 }}>Arraste o marcador para ajustar o local exato.</span>
                </>
              )}
            </Popup>
          </Marker>
        </>
      )}
      {networks.map((n) => (
        <NetworkMarker key={n.id} network={n} selected={selected && selected.id === n.id} onSelect={onSelect} dark={dark} />
      ))}
    </MapContainer>
  );
}