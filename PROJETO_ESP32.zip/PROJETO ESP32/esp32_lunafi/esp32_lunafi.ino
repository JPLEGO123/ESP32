/* -------------------------------------------------
  Firmware ESP32 para o app LUNAFI (Web Bluetooth)

  - Anuncia um servico BLE "Nordic UART" com o nome ESP32-LUNAFI
  - Recebe comandos do app:  SCAN | ANALYZE:<ssid> | OPTIMIZE
  - Responde com linhas JSON:
      {"type":"networks","networks":[{"ssid":"..","rssi":-52,"channel":6,"bssid":"AA:BB:.."}]}
------------------------------------------------- */

#include <WiFi.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#if __has_include(<BLE2902.h>)
#include <BLE2902.h>
#define HAS_BLE2902 1
#endif

// Precisam ser IGUAIS aos do app (src/lib/esp32/Esp32Service.js)
#define DEVICE_NAME   "ESP32-LUNAFI"
#define SERVICE_UUID  "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define TX_UUID       "6e400002-b5a3-f393-e0a9-e50e24dcca9e"  // app -> ESP32 (comandos)
#define RX_UUID       "6e400003-b5a3-f393-e0a9-e50e24dcca9e"  // ESP32 -> app (notificacoes)

#define MAX_NETS   15   // limite de redes enviadas
#define CHUNK_SIZE 20   // tamanho seguro por notificacao BLE (qualquer MTU)

struct Net {
  String ssid;
  int rssi;
  int channel;
  String bssid;
};

Net nets[MAX_NETS];
int netCount = 0;

BLECharacteristic* pRx = nullptr;
bool deviceConnected = false;

String rxBuf = "";
String pendingCmd = "";
volatile bool hasCmd = false;

// ---------- Utilidades ----------

String jsonEscape(const String& s) {
  String out;
  out.reserve(s.length() + 4);
  for (size_t i = 0; i < s.length(); i++) {
    char c = s[i];
    if (c == '"' || c == '\\') {
      out += '\\';
      out += c;
    } else if ((uint8_t)c < 0x20) {
      out += ' ';
    } else {
      out += c;
    }
  }
  return out;
}

// Envia texto em pedacos pequenos pela caracteristica de notificacao
void sendText(const String& text) {
  if (!deviceConnected || !pRx) return;
  size_t len = text.length();
  for (size_t off = 0; off < len; off += CHUNK_SIZE) {
    size_t n = min((size_t)CHUNK_SIZE, len - off);
    pRx->setValue((uint8_t*)(text.c_str() + off), n);
    pRx->notify();
    delay(6);
  }
}

void sendNetworks() {
  String json = "{\"type\":\"networks\",\"networks\":[";
  for (int i = 0; i < netCount; i++) {
    if (i) json += ",";
    json += "{\"ssid\":\"" + jsonEscape(nets[i].ssid) + "\"";
    json += ",\"rssi\":" + String(nets[i].rssi);
    json += ",\"channel\":" + String(nets[i].channel);
    json += ",\"bssid\":\"" + nets[i].bssid + "\"}";
  }
  json += "]}\n";
  sendText(json);
  Serial.printf("Enviadas %d redes (%u bytes)\n", netCount, (unsigned)json.length());
}

// ---------- Wi-Fi ----------

void doScan() {
  Serial.println("SCAN...");
  int n = WiFi.scanNetworks(false, true);  // true = inclui ocultas
  netCount = 0;

  for (int i = 0; i < n && netCount < MAX_NETS; i++) {
    String ssid = WiFi.SSID(i);
    if (ssid.length() == 0) continue;  // ignora redes ocultas (sem nome)

    // Evita duplicadas (varios roteadores com o mesmo nome): mantem a mais forte
    bool dup = false;
    for (int k = 0; k < netCount; k++) {
      if (nets[k].ssid == ssid) {
        dup = true;
        break;
      }
    }
    if (dup) continue;

    nets[netCount].ssid = ssid;
    nets[netCount].rssi = WiFi.RSSI(i);
    nets[netCount].channel = WiFi.channel(i);
    nets[netCount].bssid = WiFi.BSSIDstr(i);
    netCount++;
  }
  WiFi.scanDelete();
  sendNetworks();
}

// Reanalisa so o canal da rede pedida (mais rapido que um scan completo)
void doAnalyze(const String& ssid) {
  Serial.println("ANALYZE: " + ssid);
  int idx = -1;
  for (int k = 0; k < netCount; k++) {
    if (nets[k].ssid == ssid) {
      idx = k;
      break;
    }
  }
  if (idx < 0) {
    doScan();
    return;
  }

  int n = WiFi.scanNetworks(false, true, false, 300, nets[idx].channel);
  for (int i = 0; i < n; i++) {
    if (WiFi.SSID(i) == ssid) {
      nets[idx].rssi = WiFi.RSSI(i);
      nets[idx].bssid = WiFi.BSSIDstr(i);
      break;  // resultados vem ordenados por sinal: o primeiro e o mais forte
    }
  }
  WiFi.scanDelete();
  sendNetworks();
}

void handleCommand(String cmd) {
  cmd.trim();
  Serial.println("Comando: " + cmd);

  if (cmd == "SCAN") {
    doScan();
  } else if (cmd.startsWith("ANALYZE:")) {
    doAnalyze(cmd.substring(8));
  } else if (cmd == "OPTIMIZE") {
    // O ESP32 nao altera a rede/roteador: so confirma o recebimento do comando.
    sendText("{\"type\":\"ack\",\"cmd\":\"OPTIMIZE\"}\n");
  } else {
    sendText("{\"type\":\"error\",\"message\":\"comando desconhecido\"}\n");
  }
}

// ---------- BLE ----------

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* server) {
    deviceConnected = true;
    Serial.println("App conectado");
  }
  void onDisconnect(BLEServer* server) {
    deviceConnected = false;
    Serial.println("App desconectado");
    BLEDevice::startAdvertising();  // volta a anunciar para reconectar
  }
};

class CmdCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* c) {
    auto v = c->getValue();
    for (size_t i = 0; i < v.length(); i++) {
      char ch = v[i];
      if (ch == '\n' || ch == '\r') {
        if (rxBuf.length() > 0 && !hasCmd) {
          pendingCmd = rxBuf;
          hasCmd = true;
        }
        rxBuf = "";
      } else {
        rxBuf += ch;
      }
    }
  }
};

void setup() {
  Serial.begin(115200);

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();

  BLEDevice::init(DEVICE_NAME);
  BLEServer* server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());

  BLEService* service = server->createService(SERVICE_UUID);

  pRx = service->createCharacteristic(RX_UUID, BLECharacteristic::PROPERTY_NOTIFY);
#ifdef HAS_BLE2902
  pRx->addDescriptor(new BLE2902());
#endif

  BLECharacteristic* pTx = service->createCharacteristic(
    TX_UUID, BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  pTx->setCallbacks(new CmdCallbacks());

  service->start();

  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(SERVICE_UUID);
  adv->setScanResponse(true);
  BLEDevice::startAdvertising();

  Serial.println("Pronto. Procure por " DEVICE_NAME " no app.");
}

void loop() {
  // Os comandos sao executados aqui (e nao dentro do callback BLE),
  // porque o scan Wi-Fi demora alguns segundos.
  if (hasCmd) {
    String cmd = pendingCmd;
    hasCmd = false;
    handleCommand(cmd);
  }
  delay(10);
}
