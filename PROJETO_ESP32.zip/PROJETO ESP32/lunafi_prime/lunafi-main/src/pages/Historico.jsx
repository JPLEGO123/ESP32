import { useMemo, useState } from "react";
import AppChrome from "@/components/AppChrome";
import HistoryDetailModal from "@/components/HistoryDetailModal";
import SignalEvolutionChart from "@/components/history/SignalEvolutionChart";
import { useAnalysisHistory } from "@/hooks/useAnalysisHistory";
import { qualityByLabel, QUALITY_LEVELS } from "@/lib/esp32/quality";
import { History, Wifi, Signal, Clock, Trash2, Search, Gauge } from "lucide-react";

const PERIODS = [
  { id: "all", label: "Todas" },
  { id: "today", label: "Hoje" },
  { id: "7d", label: "Últimos 7 dias" },
  { id: "30d", label: "Últimos 30 dias" },
];

// Cores de qualidade aplicadas via classes de texto (adaptativas ao tema).

function periodStart(id) {
  const now = new Date();
  if (id === "today") return new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  if (id === "7d") return now.getTime() - 7 * 86400000;
  if (id === "30d") return now.getTime() - 30 * 86400000;
  return 0;
}

function SummaryCard({ icon, label, value }) {
  return (
    <div className="bg-nr-panel border border-nr-border rounded-xl p-4">
      <div className="flex items-center gap-2 text-nr-dim/60 text-[11px] uppercase tracking-wide">
        {icon} {label}
      </div>
      <p className="text-2xl font-semibold mt-2 break-words">{value}</p>
    </div>
  );
}

export default function Historico() {
  const { history, stats, clear } = useAnalysisHistory();
  const [period, setPeriod] = useState("all");
  const [mode, setMode] = useState("all");
  const [quality, setQuality] = useState("all");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(null);
  const [confirmClear, setConfirmClear] = useState(false);

  const filtered = useMemo(() => {
    const start = periodStart(period);
    const q = query.trim().toLowerCase();
    return history.filter((a) => {
      const t = new Date(a.timestamp).getTime();
      if (t < start) return false;
      if (mode !== "all" && a.mode !== mode) return false;
      if (quality !== "all" && a.overallQuality !== quality) return false;
      if (q && !a.networks.some((n) => (n.ssid || "").toLowerCase().includes(q))) return false;
      return true;
    });
  }, [history, period, mode, quality, query]);

  return (
    <AppChrome>
      <div className="max-w-6xl mx-auto p-6 sm:p-8 space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
            <History className="w-5 h-5 text-nr-accent" /> Histórico
          </h1>
          <p className="text-sm text-nr-dim/60 mt-1">Consulte as análises e medições realizadas pelo LUNAFI.</p>
        </div>

        {/* Resumo */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <SummaryCard icon={<Gauge className="w-3.5 h-3.5" />} label="Análises realizadas" value={stats.total} />
          <SummaryCard icon={<Wifi className="w-3.5 h-3.5" />} label="Redes analisadas" value={stats.networks} />
          <SummaryCard icon={<Signal className="w-3.5 h-3.5" />} label="Melhor sinal" value={stats.bestRssi != null ? `${stats.bestRssi} dBm` : "Sem dados"} />
          <SummaryCard icon={<Clock className="w-3.5 h-3.5" />} label="Última análise" value={stats.last ? new Date(stats.last.timestamp).toLocaleString("pt-BR") : "Sem dados"} />
        </div>

        {/* Filtros */}
        <div className="bg-nr-panel border border-nr-border rounded-xl p-4 space-y-4">
          <div className="flex flex-wrap gap-2">
            {PERIODS.map((p) => (
              <button
                key={p.id}
                onClick={() => setPeriod(p.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition ${
                  period === p.id
                    ? "bg-nr-accent/15 border-nr-accent text-nr-accent"
                    : "bg-nr-bg border-nr-border text-nr-dim/70 hover:border-nr-dim/40"
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <select
              value={mode}
              onChange={(e) => setMode(e.target.value)}
              className="bg-nr-bg border border-nr-border rounded-lg px-3 py-2 text-xs text-nr-text focus:outline-none focus:border-nr-accent"
            >
              <option value="all">Modo: Todos</option>
              <option value="DEMO">DEMO</option>
              <option value="ESP32">ESP32</option>
            </select>
            <select
              value={quality}
              onChange={(e) => setQuality(e.target.value)}
              className="bg-nr-bg border border-nr-border rounded-lg px-3 py-2 text-xs text-nr-text focus:outline-none focus:border-nr-accent"
            >
              <option value="all">Qualidade: Todas</option>
              {QUALITY_LEVELS.map((l) => (
                <option key={l.label} value={l.label}>
                  {l.label}
                </option>
              ))}
            </select>
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-nr-dim/40" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Pesquisar rede..."
                className="w-full bg-nr-bg border border-nr-border rounded-lg pl-9 pr-3 py-2 text-xs text-nr-text placeholder-nr-dim/30 focus:outline-none focus:border-nr-accent"
              />
            </div>
            <button
              onClick={() => {
                setPeriod("all");
                setMode("all");
                setQuality("all");
                setQuery("");
              }}
              className="px-3 py-2 rounded-lg text-xs font-medium border border-nr-border text-nr-dim/70 hover:text-nr-accent hover:border-nr-accent/60 transition whitespace-nowrap"
            >
              Limpar filtros
            </button>
          </div>
        </div>

        {/* Evolução do sinal */}
        <SignalEvolutionChart analyses={filtered} />

        {/* Lista */}
        <div className="bg-nr-panel border border-nr-border rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-nr-border">
            <h2 className="text-sm font-semibold">Histórico de análises</h2>
            <button
              onClick={() => setConfirmClear(true)}
              disabled={!history.length}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-nr-border text-rose-400 hover:bg-rose-500/10 disabled:opacity-40 transition"
            >
              <Trash2 className="w-3.5 h-3.5" /> Limpar histórico
            </button>
          </div>

          {filtered.length === 0 ? (
            <div className="px-4 py-16 text-center text-nr-dim/40">
              <History className="w-8 h-8 mx-auto mb-3 opacity-40" />
              <p className="text-sm">Nenhuma análise registrada ainda.</p>
              <p className="text-xs mt-1 max-w-xs mx-auto">
                As análises realizadas no LUNAFI (via ESP32 ou modo DEMO) aparecerão automaticamente aqui.
              </p>
            </div>
          ) : (
            <>
              {/* Tabela (desktop) */}
              <table className="hidden md:table w-full text-sm">
                <thead className="text-[11px] text-nr-dim/50 uppercase tracking-wide">
                  <tr className="border-b border-nr-border">
                    <th className="text-left font-medium px-4 py-2.5">Data e hora</th>
                    <th className="text-left font-medium px-4 py-2.5">Redes</th>
                    <th className="text-left font-medium px-4 py-2.5">Melhor sinal</th>
                    <th className="text-left font-medium px-4 py-2.5">Pior sinal</th>
                    <th className="text-left font-medium px-4 py-2.5">Qualidade</th>
                    <th className="text-left font-medium px-4 py-2.5">Modo</th>
                    <th className="text-right font-medium px-4 py-2.5">Ação</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((a) => (
                    <tr
                      key={a.id}
                      onClick={() => setSelected(a)}
                      className="border-b border-nr-border last:border-0 hover:bg-nr-dim/5 cursor-pointer"
                    >
                      <td className="px-4 py-3 text-nr-dim/80">{new Date(a.timestamp).toLocaleString("pt-BR")}</td>
                      <td className="px-4 py-3">{a.networkCount} redes</td>
                      <td className="px-4 py-3 font-mono">{a.bestRssi != null ? `${a.bestRssi} dBm` : "—"}</td>
                      <td className="px-4 py-3 font-mono">{a.worstRssi != null ? `${a.worstRssi} dBm` : "—"}</td>
                      <td className="px-4 py-3">
                        <span className={qualityByLabel(a.overallQuality).text}>{a.overallQuality}</span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={a.mode === "DEMO" ? "text-nr-demo" : "text-nr-accent"}>
                          {a.mode === "DEMO" ? "🧪 DEMO" : "📡 ESP32"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => setSelected(a)}
                          className="px-3 py-1 rounded-lg text-xs font-medium bg-nr-btn/80 hover:bg-nr-btn text-white transition"
                        >
                          Ver detalhes
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Cards (mobile) */}
              <div className="md:hidden divide-y divide-nr-border">
                {filtered.map((a) => (
                  <div key={a.id} onClick={() => setSelected(a)} className="p-4 cursor-pointer">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs text-nr-dim/70">{new Date(a.timestamp).toLocaleString("pt-BR")}</span>
                      <span className={a.mode === "DEMO" ? "text-nr-demo text-xs" : "text-nr-accent text-xs"}>
                        {a.mode === "DEMO" ? "🧪 DEMO" : "📡 ESP32"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between mt-2 text-sm">
                      <span>{a.networkCount} redes</span>
                      <span className={qualityByLabel(a.overallQuality).text}>{a.overallQuality}</span>
                    </div>
                    <div className="flex items-center justify-between mt-1 text-xs text-nr-dim/60 font-mono">
                      <span>Melhor {a.bestRssi ?? "—"}</span>
                      <span>Pior {a.worstRssi ?? "—"}</span>
                    </div>
                    <button
                      onClick={() => setSelected(a)}
                      className="w-full mt-3 py-2 rounded-lg text-xs font-medium bg-nr-btn/80 hover:bg-nr-btn text-white transition"
                    >
                      Ver detalhes
                    </button>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Modal de detalhes */}
      <HistoryDetailModal analysis={selected} onClose={() => setSelected(null)} />

      {/* Confirmação limpar */}
      {confirmClear && (
        <div className="fixed inset-0 z-[1300] flex items-center justify-center p-4" onClick={() => setConfirmClear(false)}>
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
          <div
            className="relative w-full max-w-sm rounded-2xl bg-nr-panel border border-nr-border shadow-2xl p-6 text-nr-text"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 mb-3">
              <Trash2 className="w-5 h-5 text-rose-400" />
              <h3 className="font-semibold">Limpar histórico</h3>
            </div>
            <p className="text-sm text-nr-dim/70">Tem certeza que deseja limpar todo o histórico?</p>
            <p className="text-xs text-nr-dim/50 mt-2">
              Esta ação removerá permanentemente todos os registros de análises armazenados.
            </p>
            <div className="flex gap-2 mt-5">
              <button
                onClick={() => setConfirmClear(false)}
                className="flex-1 py-2 rounded-lg text-sm font-medium border border-nr-border text-nr-dim/80 hover:bg-nr-dim/10 transition"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  clear();
                  setConfirmClear(false);
                }}
                className="flex-1 py-2 rounded-lg text-sm font-medium bg-rose-500/90 hover:bg-rose-500 text-white transition"
              >
                Mesmo assim, limpar
              </button>
            </div>
          </div>
        </div>
      )}
    </AppChrome>
  );
}