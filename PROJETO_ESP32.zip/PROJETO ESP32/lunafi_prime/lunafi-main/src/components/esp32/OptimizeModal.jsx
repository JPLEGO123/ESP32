import React from "react";
import { X, Wand2, CheckCircle2, ArrowRight, Info, AlertTriangle } from "lucide-react";
import { classifySignal } from "@/lib/esp32/quality";

function Row({ label, children }) {
  return (
    <div className="flex items-center justify-between gap-3 py-2 border-b border-nr-border last:border-0">
      <span className="text-[11px] uppercase tracking-wide text-nr-dim/40">{label}</span>
      <span className="text-sm text-right">{children}</span>
    </div>
  );
}

// Linha "antes → depois" da comparação real.
function CompareRow({ label, before, after, unit = "" }) {
  return (
    <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2 py-2 border-b border-nr-border last:border-0">
      <div className="text-center">
        <p className="text-[10px] uppercase tracking-wide text-nr-dim/40">{label} · antes</p>
        <p className="font-mono text-sm mt-0.5">
          {before ?? "—"}
          {unit && before != null ? <span className="text-[11px] text-nr-dim/40 ml-1">{unit}</span> : null}
        </p>
      </div>
      <ArrowRight className="w-4 h-4 text-nr-dim/40" />
      <div className="text-center">
        <p className="text-[10px] uppercase tracking-wide text-nr-dim/40">depois</p>
        <p className="font-mono text-sm mt-0.5">
          {after ?? "—"}
          {unit && after != null ? <span className="text-[11px] text-nr-dim/40 ml-1">{unit}</span> : null}
        </p>
      </div>
    </div>
  );
}

// Resultado REAL (medido pelo ESP32): recomendação de canal ou comparação antes/depois.
function RealBody({ result }) {
  const before = result.before || {};
  const after = result.after || null;
  const rec = result.recommended || null;
  const compare = result.mode === "compare" && after;

  let banner;
  if (compare) {
    if (result.verdict === "improved") {
      banner = { icon: CheckCircle2, color: "text-emerald-400", title: "Rede otimizada!", text: "O sinal e/ou a interferência melhoraram em relação à medição anterior." };
    } else if (result.verdict === "worse") {
      banner = { icon: AlertTriangle, color: "text-rose-500", title: "A rede piorou", text: "Depois da mudança, a medição ficou pior. Tente voltar ao canal anterior ou usar o canal recomendado." };
    } else {
      banner = { icon: Info, color: "text-amber-400", title: "Sem mudança significativa", text: "A medição ficou praticamente igual à anterior." };
    }
  } else if (result.verdict === "change_channel") {
    banner = { icon: Info, color: "text-amber-400", title: `Sugestão: use o canal ${rec?.channel ?? "—"}`, text: "Troque o canal no painel do seu roteador. Depois clique em Otimizar de novo para ver o antes e o depois." };
  } else {
    banner = { icon: CheckCircle2, color: "text-emerald-400", title: "A rede já está no melhor canal", text: "Entre os canais 1, 6 e 11, não há um com menos interferência que o atual." };
  }
  const Icon = banner.icon;
  const q = before.rssi != null ? classifySignal(before.rssi) : null;

  return (
    <>
      <div className={`flex items-start gap-2 mb-4 ${banner.color}`}>
        <Icon className="w-5 h-5 mt-0.5 shrink-0" />
        <div>
          <p className="text-sm font-medium">{banner.title}</p>
          <p className="text-xs text-nr-dim/60 mt-0.5">{banner.text}</p>
        </div>
      </div>

      <p className="text-xs text-nr-dim/40 mb-2 truncate">{result.ssid}</p>

      <div className="rounded-xl bg-nr-bg border border-nr-border px-4 py-1 mb-3">
        {compare ? (
          <>
            <CompareRow label="Sinal" before={before.rssi} after={after.rssi} unit="dBm" />
            <CompareRow label="Canal" before={before.channel} after={after.channel} />
            <CompareRow label="Interferência" before={before.index} after={after.index} />
          </>
        ) : (
          <>
            <Row label="Canal atual">{before.channel ?? "—"}</Row>
            <Row label="Sinal atual">
              <span className="font-mono">{before.rssi != null ? `${before.rssi} dBm` : "—"}</span>
              {q && <span className={`ml-2 ${q.text}`}>{before.quality}</span>}
            </Row>
            <Row label="Interferência atual">
              <span className="font-mono">{before.index ?? "—"}</span>
              {before.onChannel != null && (
                <span className="text-[11px] text-nr-dim/40 ml-2">({before.onChannel} outras no canal)</span>
              )}
            </Row>
            <Row label="Canal recomendado">
              <span className="font-mono">{rec?.channel ?? "—"}</span>
              {rec?.index != null && (
                <span className="text-[11px] text-nr-dim/40 ml-2">(interferência estimada {rec.index})</span>
              )}
            </Row>
          </>
        )}
      </div>

      <div className="rounded-xl bg-nr-bg border border-nr-border px-4 py-1">
        <Row label="Data / hora">{new Date(result.timestamp).toLocaleString("pt-BR")}</Row>
        <Row label="Origem">
          <span className="text-nr-accent">📡 ESP32</span>
        </Row>
      </div>

      <p className="text-[11px] text-nr-dim/40 mt-3">
        O ESP32 mede e recomenda — ele não altera o seu roteador. Interferência é um índice calculado a
        partir das redes vizinhas em canais sobrepostos (quanto menor, melhor).
      </p>
    </>
  );
}

// Resultado da simulação DEMO (antes/depois de RSSI).
function DemoBody({ result }) {
  const before = result.before || {};
  const after = result.after || {};
  const qBefore = before.rssi != null ? classifySignal(before.rssi) : null;
  const qAfter = after.rssi != null ? classifySignal(after.rssi) : null;
  const delta = before.rssi != null && after.rssi != null ? after.rssi - before.rssi : null;

  return (
    <>
      <div className="flex items-center gap-2 mb-4 text-emerald-400">
        <CheckCircle2 className="w-5 h-5" />
        <span className="text-sm font-medium">Otimização concluída</span>
      </div>

      <div className="rounded-xl bg-nr-bg border border-nr-border px-4 py-4 mb-3">
        <p className="text-xs text-nr-dim/40 mb-3 truncate">{result.ssid}</p>
        <div className="flex items-center justify-between gap-3">
          <div className="text-center flex-1">
            <p className="text-[11px] uppercase tracking-wide text-nr-dim/40">Antes</p>
            <p className="text-xl font-mono mt-1">
              {before.rssi != null ? `${before.rssi}` : "—"}
              <span className="text-xs text-nr-dim/40 ml-1">dBm</span>
            </p>
            <p className={`text-xs mt-1 ${qBefore ? qBefore.text : ""}`}>{before.quality || "—"}</p>
          </div>

          <ArrowRight className="w-5 h-5 text-nr-dim/40 shrink-0" />

          <div className="text-center flex-1">
            <p className="text-[11px] uppercase tracking-wide text-nr-dim/40">Depois</p>
            <p className="text-xl font-mono mt-1">
              {after.rssi != null ? `${after.rssi}` : "—"}
              <span className="text-xs text-nr-dim/40 ml-1">dBm</span>
            </p>
            <p className={`text-xs mt-1 ${qAfter ? qAfter.text : ""}`}>{after.quality || "—"}</p>
          </div>
        </div>
      </div>

      <div className="rounded-xl bg-nr-bg border border-nr-border px-4 py-1">
        <Row label="Variação">
          <span className="font-mono">{delta != null ? `${delta > 0 ? "+" : ""}${delta} dB` : "—"}</span>
        </Row>
        <Row label="Data / hora">{new Date(result.timestamp).toLocaleString("pt-BR")}</Row>
        <Row label="Origem">
          <span className="text-nr-demo">🧪 DEMO</span>
        </Row>
      </div>

      <p className="text-[11px] text-nr-dim/40 mt-3">
        Resultado simulado — não representa uma melhoria real medida pelo ESP32.
      </p>
    </>
  );
}

// Modal com o resultado da otimização.
export default function OptimizeModal({ result, onClose }) {
  if (!result) return null;

  return (
    <div className="fixed inset-0 z-[1200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div
        className="relative w-[420px] max-w-[92vw] max-h-[90vh] overflow-y-auto rounded-2xl bg-nr-panel border border-nr-border shadow-2xl p-6 text-nr-text"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold flex items-center gap-2">
            <Wand2 className="w-4 h-4 text-nr-accent" /> Otimização
            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-nr-accent/20 text-nr-accent tracking-wider">
              {result.demo ? "DEMO" : "ESP32"}
            </span>
          </h3>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-nr-dim/10 text-nr-dim/60 transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        {result.real ? <RealBody result={result} /> : <DemoBody result={result} />}
      </div>
    </div>
  );
}
