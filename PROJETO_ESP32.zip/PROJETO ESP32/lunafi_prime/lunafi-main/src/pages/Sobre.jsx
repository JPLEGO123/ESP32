import { useEffect, useState } from "react";
import AppChrome from "@/components/AppChrome";
import Logo from "@/components/Logo";
import {
  Cpu,
  Wifi,
  Bluetooth,
  MapPin,
  LayoutDashboard,
  Radio,
  Activity,
  History,
  BluetoothConnected,
  Gauge,
  FlaskConical,
  ArrowDown,
  GraduationCap,
} from "lucide-react";

const FLOW = ["REDES WI-FI", "ESP32", "BLUETOOTH / BLE", "LUNAFI", "DASHBOARD", "MAPA"];

const TECHS = [
  { icon: Cpu, title: "ESP32", desc: "Microcontrolador responsável pela coleta e processamento das informações de rede." },
  { icon: Wifi, title: "Wi-Fi", desc: "Utilizado para identificar e analisar redes próximas." },
  { icon: Bluetooth, title: "Bluetooth / BLE", desc: "Utilizado para comunicação entre o ESP32 e o sistema LUNAFI." },
  { icon: MapPin, title: "Geolocalização", desc: "Utilizada para posicionar as medições realizadas no mapa." },
  { icon: LayoutDashboard, title: "Dashboard", desc: "Interface responsável pela visualização e análise dos dados." },
];

const FEATURES = [
  { icon: Activity, title: "Monitoramento Wi-Fi", desc: "Monitoramento das redes disponíveis." },
  { icon: MapPin, title: "Mapa", desc: "Visualização geográfica das medições." },
  { icon: Gauge, title: "Análise de sinal", desc: "Análise da intensidade e qualidade das redes." },
  { icon: History, title: "Histórico", desc: "Registro das análises realizadas." },
  { icon: Cpu, title: "ESP32", desc: "Integração com hardware." },
  { icon: BluetoothConnected, title: "Bluetooth / BLE", desc: "Comunicação entre hardware e interface." },
  { icon: Radio, title: "Otimização", desc: "Recursos de análise e otimização da conexão." },
  { icon: FlaskConical, title: "Modo demo", desc: "Permite demonstrar o sistema sem o hardware conectado." },
];

// Dados do projeto acadêmico exibidos por padrão (continuam editáveis na página).
const DEFAULT_INFO = {
  instituicao: "Universidade Veiga de Almeida",
  curso: "Ciência da Computação e Engenharia da Computação",
  disciplina: "Sistemas Embarcados",
  integrantes:
    "Bernardo Borges Moore, Gabriel Aguiar de Veras da Silva, Gabriel Ferrara Portugal, João Pedro Souza Alves e Warlei Barros de Paula",
};

// Chave nova: evita que valores antigos salvos no navegador (ex.: "UVA") sobrescrevam os dados acima.
const INFO_STORAGE_KEY = "lunafi:about_info_v2";

function Card({ icon: Icon, title, desc }) {
  return (
    <div className="bg-nr-panel border border-nr-border rounded-xl p-4">
      <div className="w-9 h-9 rounded-lg bg-nr-accent/15 flex items-center justify-center mb-3">
        <Icon className="w-4 h-4 text-nr-accent" />
      </div>
      <h3 className="text-sm font-semibold">{title}</h3>
      <p className="text-xs text-nr-dim/60 mt-1 leading-relaxed">{desc}</p>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <section className="space-y-4">
      <h2 className="text-sm font-semibold uppercase tracking-wide text-nr-dim/70 border-b border-nr-border pb-2">{title}</h2>
      {children}
    </section>
  );
}

const FIELD_CLASS =
  "w-full mt-1 bg-nr-bg border border-nr-border rounded-lg px-3 py-2 text-sm text-nr-text placeholder-nr-dim/30 focus:outline-none focus:border-nr-accent transition";

function EditableField({ label, field, value, onChange, multiline = false, rows = 2 }) {
  return (
    <div>
      <label className="text-[11px] text-nr-dim/50 uppercase tracking-wide">{label}</label>
      {multiline ? (
        <textarea
          value={value}
          rows={rows}
          onChange={(e) => onChange(field, e.target.value)}
          placeholder="[Adicionar]"
          className={`${FIELD_CLASS} resize-none leading-relaxed`}
        />
      ) : (
        <input
          value={value}
          onChange={(e) => onChange(field, e.target.value)}
          placeholder="[Adicionar]"
          className={FIELD_CLASS}
        />
      )}
    </div>
  );
}

export default function Sobre() {
  const [info, setInfo] = useState(() => {
    try {
      return { ...DEFAULT_INFO, ...(JSON.parse(localStorage.getItem(INFO_STORAGE_KEY)) || {}) };
    } catch {
      return { ...DEFAULT_INFO };
    }
  });

  useEffect(() => {
    localStorage.setItem(INFO_STORAGE_KEY, JSON.stringify(info));
  }, [info]);

  const setField = (field, value) => setInfo((p) => ({ ...p, [field]: value }));

  return (
    <AppChrome>
      <div className="max-w-4xl mx-auto p-6 sm:p-8 space-y-8">
        {/* Apresentação */}
        <section className="flex flex-col items-center text-center py-6">
          <div className="h-16 w-16 flex items-center justify-center text-nr-accent">
            <Logo className="h-16 w-16" />
          </div>
          <h1 className="text-2xl font-bold tracking-[0.18em] mt-4">
            <span className="text-nr-text">LUNA</span>
            <span className="text-nr-accent">FI</span>
          </h1>
          <p className="text-sm text-nr-dim/70 mt-2">Monitoramento inteligente de redes Wi-Fi.</p>
          <p className="text-sm text-nr-dim/60 mt-4 max-w-xl leading-relaxed">
            O LUNAFI é um sistema desenvolvido para monitorar, analisar e visualizar redes Wi-Fi próximas utilizando um
            ESP32 integrado a uma interface digital.
          </p>
        </section>

        {/* Como funciona */}
        <Section title="Como funciona">
          <div className="flex flex-col items-center gap-2 bg-nr-panel border border-nr-border rounded-xl p-6">
            {FLOW.map((step, i) => (
              <div key={step} className="flex flex-col items-center gap-2">
                <span                 className="px-4 py-2 rounded-lg bg-nr-bg border border-nr-accent/40 text-nr-demo text-xs font-medium tracking-wide">
                  {step}
                </span>
                {i < FLOW.length - 1 && <ArrowDown className="w-4 h-4 text-nr-dim/40" />}
              </div>
            ))}
          </div>
          <p className="text-sm text-nr-dim/70 leading-relaxed">
            O ESP32 é responsável pela coleta das informações das redes Wi-Fi disponíveis, como intensidade do sinal,
            canal e identificação da rede. Esses dados podem ser enviados ao LUNAFI para análise e visualização.
          </p>
        </Section>

        {/* Tecnologias */}
        <Section title="Tecnologias">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {TECHS.map((t) => (
              <Card key={t.title} {...t} />
            ))}
          </div>
        </Section>

        {/* Recursos */}
        <Section title="O que o LUNAFI oferece">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {FEATURES.map((f) => (
              <Card key={f.title} {...f} />
            ))}
          </div>
        </Section>

        {/* Modo demo */}
        <Section title="Modo demo">
          <p className="text-sm text-nr-dim/70 leading-relaxed">
            O modo DEMO permite testar e apresentar a interface do LUNAFI sem a necessidade de um ESP32 conectado. Os
            dados apresentados nesse modo são simulados exclusivamente para demonstração.
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-nr-demo text-sm font-medium">
            <FlaskConical className="w-4 h-4" /> DEMO ≠ DADOS REAIS
          </div>
        </Section>

        {/* Projeto acadêmico */}
        <Section title="Projeto acadêmico">
          <div className="bg-nr-panel border border-nr-border rounded-xl p-5">
            <div className="flex items-center gap-2 mb-1">
              <GraduationCap className="w-4 h-4 text-nr-accent" />
              <h3 className="font-semibold">LUNAFI</h3>
            </div>
            <p className="text-sm text-nr-dim/60 mb-4">Sistema inteligente de monitoramento e análise de redes Wi-Fi.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <EditableField label="Instituição" field="instituicao" value={info.instituicao || ""} onChange={setField} />
              <EditableField label="Curso" field="curso" value={info.curso || ""} onChange={setField} multiline rows={2} />
              <EditableField label="Disciplina" field="disciplina" value={info.disciplina || ""} onChange={setField} />
              <EditableField label="Integrantes" field="integrantes" value={info.integrantes || ""} onChange={setField} multiline rows={4} />
            </div>
          </div>
        </Section>
      </div>
    </AppChrome>
  );
}