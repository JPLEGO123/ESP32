import React from "react";
import { Bluetooth, Loader2, FlaskConical, Unplug } from "lucide-react";

const STATE_META = {
  disconnected: { label: "Desconectado", badge: "bg-nr-border text-nr-dim/50", dot: "bg-nr-dim/30", ring: "bg-nr-border text-nr-dim/40", pulse: false },
  searching: { label: "Procurando ESP32…", badge: "bg-amber-500/15 text-amber-400", dot: "bg-amber-400", ring: "bg-amber-500/15 text-amber-400", pulse: true },
  connected: { label: "Conectado", badge: "bg-emerald-500/15 text-emerald-400", dot: "bg-emerald-400", ring: "bg-emerald-500/15 text-emerald-400", pulse: false },
  receiving: { label: "Recebendo dados", badge: "bg-nr-badge text-white", dot: "bg-nr-accent", ring: "bg-nr-badge text-white", pulse: true },
  error: { label: "Erro de comunicação", badge: "bg-rose-500/15 text-rose-400", dot: "bg-rose-500", ring: "bg-rose-500/15 text-rose-400", pulse: false },
};

export default function EspStatusPanel({ state, demoMode, error, onConnect, onStartDemo, onDisconnect }) {
  const meta = STATE_META[state] || STATE_META.disconnected;
  const searching = state === "searching";
  return (
    <div className="space-y-2.5">
      <div className="rounded-xl bg-nr-panel p-4 flex items-center gap-4">
        <div className={`w-16 h-16 rounded-full flex items-center justify-center flex-shrink-0 transition ${meta.ring}`}>
          {searching ? <Loader2 className="w-7 h-7 animate-spin" /> : <Bluetooth className="w-7 h-7" />}
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <p className="font-semibold text-sm leading-tight">ESP32</p>
            {demoMode && (
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-nr-accent/20 text-nr-accent tracking-wider">DEMO</span>
            )}
          </div>
          <span className={`inline-flex items-center gap-1.5 mt-2 px-2.5 py-0.5 rounded-full text-[11px] font-medium ${meta.badge}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${meta.dot} ${meta.pulse ? "animate-pulse" : ""}`} />
            {meta.label}
          </span>
          {(state === "connected" || state === "receiving") && (
            <p className="text-[10px] text-nr-dim/40 mt-1">
              {demoMode ? "Simulação ativa" : "Dispositivo real"}
            </p>
          )}
        </div>
      </div>

      <div className="flex flex-wrap gap-2.5">
        <button
          onClick={onConnect}
          disabled={searching}
          className="flex-1 h-11 rounded-lg bg-nr-btn hover:bg-nr-btn/85 text-white text-sm font-medium transition disabled:opacity-50 flex items-center justify-center gap-2"
        >
          <Bluetooth className="w-4 h-4" /> Conectar ESP32
        </button>
        <button
          onClick={demoMode ? onDisconnect : onStartDemo}
          className="h-11 px-3 rounded-lg border border-nr-border hover:border-nr-accent/60 text-nr-dim/70 hover:text-nr-accent text-sm transition flex items-center gap-2"
        >
          {demoMode ? <Unplug className="w-4 h-4" /> : <FlaskConical className="w-4 h-4" />}
          {demoMode ? "Encerrar" : "Demo"}
        </button>
      </div>

      {error && <p className="text-[11px] text-rose-400 px-1">{error}</p>}
    </div>
  );
}