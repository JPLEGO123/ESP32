import React from "react";
import { Wand2, Loader2, CheckCircle2 } from "lucide-react";

export default function OptimizeControl({ stages, stage, onOptimize, demoMode }) {
  const running = stage != null;
  return (
    <div className="rounded-xl border border-nr-border p-3 flex flex-col gap-2.5">
      <button
        onClick={onOptimize}
        disabled={running}
        className="flex items-center justify-center gap-2 h-11 rounded-lg bg-nr-btn hover:bg-nr-btn/85 text-white text-sm font-medium transition disabled:opacity-40"
      >
        {running ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
        Otimizar com ESP32
        {demoMode && !running && (
          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-white/20 tracking-wider">DEMO</span>
        )}
      </button>
      {running && (
        <div className="space-y-1.5">
          {stages.map((label, i) => {
            const done = i < stage;
            const current = i === stage;
            return (
              <div key={label} className={`flex items-center gap-2 text-xs ${done || current ? "text-nr-text" : "text-nr-dim/30"}`}>
                {done ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                ) : current ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-nr-accent" />
                ) : (
                  <span className="w-3.5 h-3.5 rounded-full border border-nr-dim/20" />
                )}
                {label}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}