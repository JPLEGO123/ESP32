import React from "react";
import { X, Loader2, CheckCircle2, Radar } from "lucide-react";
import { classifySignal } from "@/lib/esp32/quality";

function Row({ label, children }) {
  return (
    <div className="flex items-center justify-between gap-3 py-2 border-b border-nr-border last:border-0">
      <span className="text-[11px] uppercase tracking-wide text-nr-dim/40">{label}</span>
      <span className="text-sm text-right">{children}</span>
    </div>
  );
}

// Modal de resultado da análise de rede — identifica claramente o modo DEMO.
export default function AnalysisModal({ analysis, onClose }) {
  if (!analysis) return null;
  const running = analysis.status === "running";
  const q = analysis.rssi != null ? classifySignal(analysis.rssi) : null;

  return (
    <div className="fixed inset-0 z-[1200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="relative w-[420px] max-w-[92vw] max-h-[90vh] overflow-y-auto rounded-2xl bg-nr-panel border border-nr-border shadow-2xl p-6 text-nr-text"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold flex items-center gap-2">
            <Radar className="w-4 h-4 text-nr-accent" /> Análise de rede
            {analysis.demo && (
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-nr-accent/20 text-nr-accent tracking-wider">
                DEMO
              </span>
            )}
          </h3>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-nr-dim/10 text-nr-dim/60 transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        {running ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <Loader2 className="w-7 h-7 animate-spin text-nr-accent mb-3" />
            <p className="text-sm">Analisando rede…</p>
            <p className="text-xs text-nr-dim/40 mt-1">{analysis.ssid}</p>
          </div>
        ) : (
          <>
            <div className="flex items-center gap-2 mb-4 text-emerald-400">
              <CheckCircle2 className="w-5 h-5" />
              <span className="text-sm font-medium">Análise concluída</span>
            </div>

            <div className="rounded-xl bg-nr-bg border border-nr-border px-4 py-1">
              <Row label="SSID">
                <span className="font-medium">{analysis.ssid}</span>
              </Row>
              <Row label="RSSI">
                <span className="font-mono">{analysis.rssi != null ? `${analysis.rssi} dBm` : "—"}</span>
              </Row>
              <Row label="Qualidade">{q ? <span className={q.text}>{analysis.quality}</span> : "—"}</Row>
              <Row label="Canal">{analysis.channel ?? "—"}</Row>
              {analysis.onChannel != null && <Row label="Outras redes no canal">{analysis.onChannel}</Row>}
              {analysis.interference != null && (
                <Row label="Interferência (índice)">
                  <span className="font-mono">{analysis.interference}</span>
                </Row>
              )}
              <Row label="BSSID">
                <span className="font-mono text-xs">{analysis.bssid || "—"}</span>
              </Row>
              {analysis.demo && <Row label="Estabilidade simulada">{analysis.stability ?? "—"}</Row>}
              <Row label="Data / hora">{new Date(analysis.timestamp).toLocaleString("pt-BR")}</Row>
              <Row label="Origem">
                <span className={analysis.demo ? "text-nr-demo" : "text-nr-accent"}>
                  {analysis.demo ? "🧪 DEMO" : "📡 ESP32"}
                </span>
              </Row>
            </div>

            {analysis.demo && (
              <p className="text-[11px] text-nr-dim/40 mt-3">
                Resultado simulado — não é uma medição real do ESP32.
              </p>
            )}
          </>
        )}
      </div>
    </div>
  );
}