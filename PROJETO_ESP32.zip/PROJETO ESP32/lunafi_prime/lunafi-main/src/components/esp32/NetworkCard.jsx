import React from "react";
import { Wifi, Radar } from "lucide-react";
import { classifySignal, signalPercent } from "@/lib/esp32/quality";

export default function NetworkCard({ network, selected, onSelect, onAnalyze }) {
  const q = classifySignal(network.rssi);
  const pct = signalPercent(network.rssi);
  return (
    <div
      onClick={onSelect}
      className={`w-full text-left px-4 py-3 border-b border-nr-border cursor-pointer transition flex items-start gap-3 hover:bg-nr-accent/10 ${
        selected ? "bg-nr-accent/15" : ""
      }`}
    >
      <div className={`mt-0.5 flex-shrink-0 w-9 h-9 rounded-lg flex items-center justify-center ${q.chip}`}>
        <Wifi className={`w-4 h-4 ${q.text}`} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <p className="text-sm font-medium truncate">{network.ssid}</p>
          <span className="text-xs font-mono text-nr-dim/70 flex-shrink-0">{network.rssi} dBm</span>
        </div>
        <div className="flex items-center gap-2 mt-1 text-[11px]">
          <span className={`px-1.5 py-0.5 rounded font-medium ${q.chip} ${q.text}`}>{q.label}</span>
          <span className="text-nr-dim/40">Canal {network.channel ?? "—"}</span>
        </div>
        <div className="h-1 rounded-full bg-nr-border mt-2 overflow-hidden">
          <div className={`h-full rounded-full ${q.bar}`} style={{ width: `${pct}%` }} />
        </div>
        {network.bssid && <p className="text-[10px] text-nr-dim/30 mt-1 font-mono">{network.bssid}</p>}
      </div>
      <button
        onClick={(e) => {
          e.stopPropagation();
          onAnalyze(network.ssid);
        }}
        title="Analisar rede"
        className="mt-0.5 p-1.5 rounded-lg text-nr-dim/40 hover:text-nr-accent hover:bg-nr-accent/10 transition flex-shrink-0"
      >
        <Radar className="w-4 h-4" />
      </button>
    </div>
  );
}