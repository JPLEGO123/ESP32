import { useCallback, useRef, useState } from "react";
import { WebBluetoothEsp32Service, ESP32_STATES } from "@/lib/esp32/Esp32Service";
import { SimEsp32Service } from "@/lib/esp32/SimEsp32Service";
import { classifySignal } from "@/lib/esp32/quality";

const OPTIMIZE_STAGES_REAL = [
  "Preparando otimização...",
  "ESP32 executando...",
  "Analisando sinal...",
  "Otimização concluída",
];

// Fluxo de otimização do MODO DEMO — claramente identificado como simulação.
const OPTIMIZE_STAGES_DEMO = [
  "Otimização DEMO iniciada...",
  "Analisando condições da rede...",
  "Simulando otimização...",
  "✓ Otimização concluída",
];

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

// Hook que gerencia a comunicação com o ESP32 (Bluetooth real ou modo demonstração).
export function useEsp32() {
  const [connectionState, setConnectionState] = useState(ESP32_STATES.DISCONNECTED);
  const [demoMode, setDemoMode] = useState(false);
  const [networks, setNetworks] = useState([]);
  const [lastUpdate, setLastUpdate] = useState(null);
  const [error, setError] = useState("");
  const [optimizeStage, setOptimizeStage] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [optimizeResult, setOptimizeResult] = useState(null);
  const serviceRef = useRef(null);
  const timersRef = useRef([]);
  const networksRef = useRef([]);
  const demoRef = useRef(false);
  // Respostas reais do ESP32 que ainda estamos aguardando (análise / otimização).
  const analysisPendingRef = useRef(null);
  const optimizePendingRef = useRef(false);

  const clearTimers = useCallback(() => {
    timersRef.current.forEach(clearTimeout);
    timersRef.current = [];
  }, []);

  const attach = useCallback((service, isDemo) => {
    service.onState(setConnectionState);
    service.onData((data) => {
      if (data.type === "networks") {
        networksRef.current = data.networks || [];
        setNetworks(data.networks || []);
        setLastUpdate(new Date());
      } else if (data.type === "analysis") {
        // Análise REAL medida pelo ESP32 (mostrada também no display OLED).
        const id = analysisPendingRef.current;
        if (!id) return;
        analysisPendingRef.current = null;
        const rssi = typeof data.rssi === "number" ? data.rssi : null;
        setAnalysis({
          status: "done",
          id,
          ssid: data.ssid,
          rssi,
          quality: rssi != null ? classifySignal(rssi).label : "—",
          channel: data.channel ?? null,
          bssid: data.bssid ?? null,
          onChannel: data.onChannel ?? null,
          interference: data.index ?? null,
          stability: null,
          timestamp: new Date().toISOString(),
          demo: false,
        });
      } else if (data.type === "optimize") {
        // Resultado REAL da otimização (recomendação de canal ou comparação antes/depois).
        if (!optimizePendingRef.current) return;
        optimizePendingRef.current = false;
        clearTimers();
        setOptimizeStage(3);
        const withQuality = (m) =>
          m ? { ...m, quality: typeof m.rssi === "number" ? classifySignal(m.rssi).label : "—" } : null;
        timersRef.current.push(
          setTimeout(() => {
            setOptimizeStage(null);
            setOptimizeResult({
              id: `opt-${Date.now()}`,
              demo: false,
              real: true,
              mode: data.mode,
              verdict: data.verdict,
              ssid: data.ssid,
              before: withQuality(data.before),
              after: withQuality(data.after),
              recommended: data.recommended || null,
              timestamp: new Date().toISOString(),
            });
          }, 700)
        );
      } else if (data.type === "error") {
        analysisPendingRef.current = null;
        optimizePendingRef.current = false;
        clearTimers();
        setAnalysis(null);
        setOptimizeStage(null);
        setError(data.message ? `ESP32: ${data.message}` : "O ESP32 reportou um erro.");
      }
    });
    serviceRef.current = service;
    demoRef.current = isDemo;
    setDemoMode(isDemo);
    setAnalysis(null);
    setOptimizeResult(null);
    setOptimizeStage(null);
  }, [clearTimers]);

  const connectBluetooth = useCallback(async () => {
    setError("");
    try {
      await serviceRef.current?.disconnect();
    } catch (e) {
      /* ignora */
    }
    const svc = new WebBluetoothEsp32Service();
    attach(svc, false);
    try {
      await svc.connect();
    } catch (e) {
      if (e?.name === "NotFoundError") {
        setError("Seleção do dispositivo cancelada.");
      } else {
        setError(e?.message || "Não foi possível conectar ao ESP32 via Bluetooth.");
      }
    }
  }, [attach]);

  const startDemo = useCallback(async () => {
    setError("");
    try {
      await serviceRef.current?.disconnect();
    } catch (e) {
      /* ignora */
    }
    const svc = new SimEsp32Service();
    attach(svc, true);
    try {
      await svc.connect();
    } catch (e) {
      setError(e?.message || "Falha ao iniciar o modo demonstração.");
    }
  }, [attach]);

  const disconnect = useCallback(async () => {
    clearTimers();
    try {
      await serviceRef.current?.disconnect();
    } catch (e) {
      /* ignora */
    }
    serviceRef.current = null;
    networksRef.current = [];
    analysisPendingRef.current = null;
    optimizePendingRef.current = false;
    demoRef.current = false;
    setDemoMode(false);
    setNetworks([]);
    setOptimizeStage(null);
    setAnalysis(null);
    setOptimizeResult(null);
  }, [clearTimers]);

  const isConnected = connectionState === ESP32_STATES.CONNECTED || connectionState === ESP32_STATES.RECEIVING;

  const scan = useCallback(async () => {
    if (!serviceRef.current?.isConnected()) return;
    try {
      await serviceRef.current.sendCommand("SCAN");
    } catch (e) {
      setError(e?.message || "Falha ao enviar comando SCAN.");
    }
  }, []);

  // Análise de rede — funciona no modo DEMO (simulada) e no modo real (ESP32).
  const analyzeNetwork = useCallback(async (network) => {
    const ssid = typeof network === "string" ? network : network?.ssid;
    if (!ssid) return;
    const svc = serviceRef.current;
    const isDemo = demoRef.current;

    if (!svc?.isConnected()) {
      setError("ESP32 não conectado. Conecte o dispositivo para executar a análise real.");
      return;
    }

    setError("");
    const id = `an-${Date.now()}`;
    setAnalysis({ status: "running", id, ssid, demo: isDemo });
    if (!isDemo) analysisPendingRef.current = id;

    try {
      await svc.sendCommand(`ANALYZE:${ssid}`);
    } catch (e) {
      analysisPendingRef.current = null;
      setError(e?.message || "Falha ao analisar a rede.");
      setAnalysis(null);
      return;
    }

    if (!isDemo) {
      // Modo real: o resultado chega do ESP32 (mensagem "analysis"). Se não chegar, avisa.
      timersRef.current.push(
        setTimeout(() => {
          if (analysisPendingRef.current === id) {
            analysisPendingRef.current = null;
            setAnalysis(null);
            setError("O ESP32 não respondeu à análise. Tente novamente.");
          }
        }, 25000)
      );
      return;
    }

    // Modo DEMO: resultado simulado a partir da lista atual.
    timersRef.current.push(
      setTimeout(() => {
        const net = networksRef.current.find((n) => n.ssid === ssid);
        const rssi = typeof net?.rssi === "number" ? net.rssi : null;
        setAnalysis({
          status: "done",
          id,
          ssid,
          rssi,
          quality: rssi != null ? classifySignal(rssi).label : "—",
          channel: net?.channel ?? null,
          bssid: net?.bssid ?? null,
          stability: `${rand(82, 99)}%`,
          timestamp: new Date().toISOString(),
          demo: true,
        });
      }, 500)
    );
  }, []);

  // Otimização.
  // - DEMO: simulação com resultado antes/depois (claramente marcada como DEMO).
  // - REAL: o ESP32 mede a rede escolhida e recomenda o melhor canal; numa 2ª execução
  //   (depois de trocar o canal no roteador) ele compara ANTES x DEPOIS. O ESP32 não altera o roteador.
  const optimize = useCallback(async (network) => {
    const svc = serviceRef.current;
    const isDemo = demoRef.current;

    if (!svc?.isConnected()) {
      setError("ESP32 não conectado. Conecte o dispositivo para executar a otimização real.");
      return;
    }

    setError("");
    clearTimers();
    setOptimizeResult(null);
    setOptimizeStage(0);

    const target =
      network || [...networksRef.current].sort((a, b) => b.rssi - a.rssi)[0] || null;

    if (!isDemo) optimizePendingRef.current = true;

    try {
      await svc.sendCommand(target?.ssid ? `OPTIMIZE:${target.ssid}` : "OPTIMIZE");
    } catch (e) {
      optimizePendingRef.current = false;
      setOptimizeStage(null);
      setError(e?.message || "Falha ao enviar comando OPTIMIZE.");
      return;
    }

    if (!isDemo) {
      // Modo real: avança as etapas e aguarda o resultado do ESP32 (mensagem "optimize").
      timersRef.current.push(setTimeout(() => setOptimizeStage(1), 1200));
      timersRef.current.push(setTimeout(() => setOptimizeStage(2), 2500));
      timersRef.current.push(
        setTimeout(() => {
          if (optimizePendingRef.current) {
            optimizePendingRef.current = false;
            setOptimizeStage(null);
            setError("O ESP32 não respondeu à otimização. Tente novamente.");
          }
        }, 25000)
      );
      return;
    }

    timersRef.current.push(setTimeout(() => setOptimizeStage(1), 1200));
    timersRef.current.push(setTimeout(() => setOptimizeStage(2), 2500));
    timersRef.current.push(setTimeout(() => setOptimizeStage(3), 3800));
    timersRef.current.push(
      setTimeout(() => {
        setOptimizeStage(null);
        // Comparação antes/depois apenas na simulação DEMO (nunca afirmamos melhoria real).
        if (target) {
          const beforeRssi = target.rssi;
          const afterRssi = clamp(beforeRssi + rand(6, 16), -90, -35);
          setOptimizeResult({
            id: `opt-${Date.now()}`,
            demo: true,
            ssid: target.ssid,
            before: { rssi: beforeRssi, quality: classifySignal(beforeRssi).label },
            after: { rssi: afterRssi, quality: classifySignal(afterRssi).label },
            timestamp: new Date().toISOString(),
          });
        }
      }, 4600)
    );
  }, [clearTimers]);

  return {
    connectionState,
    demoMode,
    networks,
    lastUpdate,
    error,
    optimizeStage,
    optimizeStages: demoMode ? OPTIMIZE_STAGES_DEMO : OPTIMIZE_STAGES_REAL,
    analysis,
    optimizeResult,
    isConnected,
    connectBluetooth,
    startDemo,
    disconnect,
    scan,
    analyzeNetwork,
    optimize,
    setAnalysis,
    setOptimizeResult,
    setError,
  };
}