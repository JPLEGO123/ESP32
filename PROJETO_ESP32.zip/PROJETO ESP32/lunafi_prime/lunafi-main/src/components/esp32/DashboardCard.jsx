import React from "react";
import { Wifi, Trophy, MousePointerClick, Clock } from "lucide-react";
import { classifySignal } from "@/lib/esp32/quality";

const fmtTime = (d) => (d ? new Date(d).toLocaleTimeString("pt-BR") : "—");

function Stat({ icon, label, value, sub }) {
  return (
    <div className="rounded-lg bg-nr-bg border border-nr-border p-2.5 min-w-0">
      <div className="flex items-center gap-1.5 text-nr-dim/40">
        {icon}
        <span className="text-[10px] uppercase tracking-wide truncate">{label}</span>
      </div>
      <p className="text-sm font-semibold mt-1 truncate">{value}</p>
      {sub && <p className="text-[10px] text-nr-dim/40 truncate">{sub}</p>}
    </div>
  );
}

export default function DashboardCard({ networks, lastUpdate, selected }) {
  const best = networks.length ? networks.reduce((a, b) => (b.rssi > a.rssi ? b : a)) : null;
  const selQ = selected ? classifySignal(selected.rssi) : null;
  return (
    <div className="rounded-xl bg-nr-panel p-4 space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-xs text-nr-dim/50">Dashboard ESP32</span>
        <Wifi className="w-4 h-4 text-nr-accent" />
      </div>
      <div className="grid grid-cols-2 gap-2.5">
        <Stat icon={<Wifi className="w-3 h-3" />} label="Redes" value={networks.length} />
        <Stat icon={<Trophy className="w-3 h-3" />} label="Melhor sinal" value={best ? `${best.rssi} dBm` : "—"} sub={best?.ssid} />
        <Stat icon={<MousePointerClick className="w-3 h-3" />} label="Selecionada" value={selected?.ssid || "—"} sub={selQ ? `Qualidade: ${selQ.label}` : null} />
        <Stat icon={<Clock className="w-3 h-3" />} label="Atualização" value={fmtTime(lastUpdate)} />
      </div>
    </div>
  );
}