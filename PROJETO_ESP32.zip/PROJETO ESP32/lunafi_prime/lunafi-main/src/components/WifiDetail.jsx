import React from "react";
import { Wifi, MapPin, X, Navigation, Globe, Building2, Tag } from "lucide-react";

export default function WifiDetail({ spot, onClose }) {
  if (!spot) return null;
  const openInMaps = () => {
    window.open(`https://www.openstreetmap.org/?mlat=${spot.lat}&mlon=${spot.lon}#map=18/${spot.lat}/${spot.lon}`, "_blank");
  };

  return (
    <div className="absolute right-0 top-0 bottom-0 w-full sm:w-[360px] bg-nr-bg border-l border-nr-border z-[1000] flex flex-col text-nr-text">
      <div className="flex items-center justify-between px-5 py-4 border-b border-nr-border">
        <h3 className="font-semibold">Detalhes do ponto</h3>
        <button onClick={onClose} className="p-2 rounded-lg hover:bg-nr-dim/10 text-nr-dim/50 transition">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-5 space-y-5">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-nr-accent/15 text-nr-accent flex items-center justify-center">
            <Wifi className="w-6 h-6" />
          </div>
          <div className="min-w-0">
            <h4 className="font-semibold leading-tight">{spot.name}</h4>
            <p className="text-xs text-nr-dim/40 mt-0.5">Acesso à internet</p>
          </div>
        </div>

        <div className="space-y-1 text-sm">
          <Row icon={<MapPin className="w-4 h-4" />} label="Localização">
            {spot.lat.toFixed(5)}, {spot.lon.toFixed(5)}
          </Row>
          {spot.distance != null && (
            <Row icon={<Navigation className="w-4 h-4" />} label="Distância">
              {(spot.distance / 1000).toFixed(2)} km de você
            </Row>
          )}
          {spot.operator && <Row icon={<Building2 className="w-4 h-4" />} label="Operadora">{spot.operator}</Row>}
          {spot.access && <Row icon={<Globe className="w-4 h-4" />} label="Tipo de acesso">{spot.access}</Row>}
          {spot.tags && <Row icon={<Tag className="w-4 h-4" />} label="Categoria">{spot.tags}</Row>}
        </div>

        <button
          onClick={openInMaps}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-nr-btn hover:bg-nr-btn/85 text-white text-sm font-medium transition"
        >
          <Navigation className="w-4 h-4" /> Traçar rota
        </button>
      </div>
    </div>
  );
}

function Row({ icon, label, children }) {
  return (
    <div className="flex items-start gap-3 py-2.5 border-b border-nr-border">
      <div className="text-nr-accent/70 mt-0.5">{icon}</div>
      <div className="flex-1">
        <p className="text-[11px] text-nr-dim/40 uppercase tracking-wide">{label}</p>
        <p className="mt-0.5 capitalize">{children}</p>
      </div>
    </div>
  );
}