import React, { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import WifiMap from "@/components/WifiMap";
import HelpMenu from "@/components/HelpMenu";
import { useAnalysisHistory } from "@/hooks/useAnalysisHistory";
import SystemMenu from "@/components/SystemMenu";
import { useRadar } from "@/hooks/useRadar";
import { useEsp32 } from "@/hooks/useEsp32";
import { classifySignal } from "@/lib/esp32/quality";
import { haversine, describeAccuracy } from "@/lib/geo";
import EspStatusPanel from "@/components/esp32/EspStatusPanel";
import OptimizeControl from "@/components/esp32/OptimizeControl";
import AnalysisModal from "@/components/esp32/AnalysisModal";
import OptimizeModal from "@/components/esp32/OptimizeModal";
import DashboardCard from "@/components/esp32/DashboardCard";
import NetworkList from "@/components/esp32/NetworkList";
import NetworkDetail from "@/components/esp32/NetworkDetail";
import Logo from "@/components/Logo";
import { useTheme } from "@/lib/theme";
import { Minus, X, Power, Loader2, MapPinOff, MapPin } from "lucide-react";

// Distribui coordenadas DEMO ao redor do usuário (padrão girassol), estável por índice.
// NÃO representam posições reais dos roteadores — apenas para visualização em demonstração.
function demoOffset(lat, lon, radiusM, i) {
  const angle = i * 2.39996; // ângulo áureo (~137.5°)
  const dist = radiusM * (0.3 + ((i * 37) % 40) / 100); // 30%–70% do raio
  const dLat = (dist * Math.cos(angle)) / 111111;
  const dLon = (dist * Math.sin(angle)) / (111111 * Math.cos((lat * Math.PI) / 180));
  return [lat + dLat, lon + dLon];
}

export default function Home() {
  const [selectedNetwork, setSelectedNetwork] = useState(null);
  const [systemOpen, setSystemOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const [config, setConfig] = useState({ radius: 500, maxResults: 30, nameFilter: "" });

  // Tema é global (contexto); a config local guarda apenas os demais parâmetros.
  const handleConfigChange = (next) => {
    setTheme(next.theme);
    setConfig({ radius: next.radius, maxResults: next.maxResults, nameFilter: next.nameFilter });
  };

  const radar = useRadar();
  const esp32 = useEsp32();

  // Fonte ÚNICA de redes para a lista E para o mapa.
  // Marcadores só existem com o radar ativo (geolocalização disponível).
  // - DEMO: coordenadas de demonstração próximas ao usuário (demo: true).
  // - REAL: local da medição = posição atual do dispositivo (não a do roteador).
  const networks = useMemo(() => {
    if (radar.state !== "active" || !radar.userPos) return [];
    const [lat0, lon0] = radar.userPos;
    const radius = config.radius;
    return esp32.networks
      .map((net, i) => {
        let latitude, longitude;
        if (esp32.demoMode) {
          [latitude, longitude] = demoOffset(lat0, lon0, radius, i);
        } else {
          latitude = lat0;
          longitude = lon0;
        }
        const q = classifySignal(net.rssi);
        return {
          id: net.bssid || `${net.ssid}-${i}`,
          ssid: net.ssid,
          rssi: net.rssi,
          channel: net.channel,
          bssid: net.bssid,
          quality: q.label,
          latitude,
          longitude,
          timestamp: esp32.lastUpdate ? new Date(esp32.lastUpdate).toISOString() : new Date().toISOString(),
          demo: !!esp32.demoMode,
        };
      })
      .filter((n) => haversine(radar.userPos, [n.latitude, n.longitude]) <= radius);
  }, [radar.state, radar.userPos, esp32.networks, esp32.demoMode, esp32.lastUpdate, config.radius]);

  // Seleção válida apenas se ainda estiver na lista (sincroniza lista ↔ mapa).
  const activeSelected = selectedNetwork ? networks.find((n) => n.id === selectedNetwork.id) || null : null;

  // Registra cada análise (scan) no histórico persistente — alimenta a página Histórico.
  const { add: addAnalysisRecord } = useAnalysisHistory();
  const lastRecordedKey = useRef(null);
  useEffect(() => {
    if (networks.length > 0 && esp32.lastUpdate) {
      const key = `${esp32.lastUpdate.getTime()}-${esp32.demoMode ? "demo" : "real"}`;
      if (lastRecordedKey.current !== key) {
        lastRecordedKey.current = key;
        addAnalysisRecord({
          networks,
          userPos: radar.userPos,
          mode: esp32.demoMode ? "DEMO" : "ESP32",
          demo: esp32.demoMode,
          timestamp: new Date(esp32.lastUpdate).toISOString(),
        });
      }
    }
  }, [networks, esp32.lastUpdate, esp32.demoMode, radar.userPos, addAnalysisRecord]);

  // Registra no Histórico cada análise de rede concluída (DEMO ou ESP32).
  const lastAnalysisKey = useRef(null);
  useEffect(() => {
    const a = esp32.analysis;
    if (!a || a.status !== "done" || lastAnalysisKey.current === a.id) return;
    lastAnalysisKey.current = a.id;
    addAnalysisRecord({
      networks: [
        {
          id: a.bssid || `${a.ssid}-analysis`,
          ssid: a.ssid,
          rssi: a.rssi,
          quality: a.quality,
          channel: a.channel,
          bssid: a.bssid,
          latitude: radar.userPos ? radar.userPos[0] : null,
          longitude: radar.userPos ? radar.userPos[1] : null,
          timestamp: a.timestamp,
          demo: a.demo,
        },
      ],
      userPos: radar.userPos,
      mode: a.demo ? "DEMO" : "ESP32",
      demo: a.demo,
      timestamp: a.timestamp,
    });
  }, [esp32.analysis, radar.userPos, addAnalysisRecord]);

  const selectNetwork = (n) => setSelectedNetwork(n);

  const radarStatusText = !esp32.isConnected
    ? "Radar ativo — aguardando ESP32"
    : networks.length === 0
    ? "Radar ativo — nenhuma rede encontrada"
    : `Radar ativo — ${networks.length} redes próximas`;

  return (
    <div className={`netradar-theme min-h-screen lg:h-screen w-full flex flex-col bg-nr-bg text-nr-text overflow-x-hidden lg:overflow-hidden font-body select-none ${theme === "light" ? "light" : ""}`}>
      {/* Title bar */}
      <header className="flex items-center justify-between h-[52px] px-4 bg-nr-bg border-b border-nr-border">
        <div className="flex items-center gap-2.5">
          <div className="h-[52px] w-[52px] flex items-center justify-center text-nr-accent">
            <Logo className="h-11 w-11" />
          </div>
          <span className="font-heading font-bold tracking-[0.18em] text-sm whitespace-nowrap select-none">
            <span className="text-nr-text">LUNA</span>
            <span className="text-nr-accent">FI</span>
          </span>
        </div>
        <div className="flex items-center gap-1">
          <button className="w-7 h-7 rounded hover:bg-nr-dim/10 flex items-center justify-center text-nr-dim/70 transition">
            <Minus className="w-4 h-4" />
          </button>
          <button className="w-7 h-7 rounded hover:bg-rose-500/80 flex items-center justify-center text-nr-dim/70 transition">
            <X className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Menu bar */}
      <nav className="flex items-center gap-5 h-8 px-4 text-xs text-nr-dim/70 border-b border-nr-border">
        <button onClick={() => setSystemOpen(true)} className="hover:text-nr-accent cursor-pointer transition">Sistema</button>
        <Link to="/" className="hover:text-nr-accent cursor-pointer transition">Rede</Link>
        <Link to="/historico" className="hover:text-nr-accent cursor-pointer transition">Histórico</Link>
        <HelpMenu />
      </nav>

      {/* Body */}
      {/* Celular (<768): 1 coluna vertical · Tablet (768–1023): painel | mapa + lista embaixo · Desktop (≥1024): 3 colunas */}
      <div className="flex-1 relative grid grid-cols-1 md:grid-cols-[320px_minmax(0,1fr)] lg:grid-cols-[280px_minmax(0,1fr)_280px] xl:grid-cols-[320px_minmax(0,1fr)_300px] lg:grid-rows-[minmax(0,1fr)] lg:min-h-0">
        {/* Left control panel */}
        <aside className="min-w-0 bg-nr-bg border-b md:border-b-0 md:border-r border-nr-border flex flex-col gap-4 p-4 lg:p-5 lg:min-h-0 lg:overflow-y-auto">
          <EspStatusPanel
            state={esp32.connectionState}
            demoMode={esp32.demoMode}
            error={esp32.error}
            onConnect={esp32.connectBluetooth}
            onStartDemo={esp32.startDemo}
            onDisconnect={esp32.disconnect}
          />

          <div className="rounded-xl border border-nr-border p-3 flex flex-col gap-2.5">
            <button
              onClick={radar.togglePower}
              disabled={radar.state === "locating"}
              className="flex items-center justify-center gap-2 h-11 rounded-lg bg-nr-btn hover:bg-nr-btn/85 text-white text-sm font-medium transition disabled:opacity-50"
            >
              {radar.state === "locating" ? <Loader2 className="w-4 h-4 animate-spin" /> : <Power className="w-4 h-4" />}
              {radar.state === "active" ? "Desligar radar" : "Ativar radar"}
            </button>
          </div>

          <OptimizeControl
            stages={esp32.optimizeStages}
            stage={esp32.optimizeStage}
            onOptimize={() => esp32.optimize(activeSelected)}
            demoMode={esp32.demoMode}
          />

          <DashboardCard networks={networks} lastUpdate={esp32.lastUpdate} selected={activeSelected} />

          {radar.state === "error" && <p className="text-[11px] text-rose-400 px-1">{radar.error}</p>}
        </aside>

        {/* Map */}
        <main className="relative min-w-0 h-[45vh] min-h-[350px] md:h-auto md:min-h-[480px] lg:min-h-0">
          <div className="absolute inset-0">
            <WifiMap
              userPos={radar.userPos}
              accuracy={radar.source === "gps" ? radar.accuracy : null}
              followUser={radar.source === "gps"}
              onUserMove={radar.setManualPos}
              networks={networks}
              selected={activeSelected}
              onSelect={selectNetwork}
              dark={theme === "dark"}
              radius={config.radius}
            />
          </div>

          {radar.state === "off" && (
            <div className="absolute inset-0 bg-nr-bg/70 backdrop-blur-sm flex flex-col items-center justify-center z-[400]">
              <Power className="w-10 h-10 text-nr-dim/30 mb-3" />
              <p className="text-sm text-nr-dim/70">Ative o radar para analisar redes próximas</p>
            </div>
          )}

          {radar.state === "error" && (
            <div className="absolute inset-0 bg-nr-bg/70 backdrop-blur-sm flex flex-col items-center justify-center z-[400] px-6 text-center">
              <MapPinOff className="w-10 h-10 text-rose-400/60 mb-3" />
              <p className="text-sm text-nr-dim/80 max-w-xs">{radar.error}</p>
              <button
                onClick={radar.togglePower}
                className="mt-4 px-4 py-2 rounded-lg bg-nr-btn hover:bg-nr-btn/85 text-white text-sm font-medium transition"
              >
                Tentar novamente
              </button>
            </div>
          )}

          {radar.state === "locating" && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 z-[400] flex items-center gap-2 bg-nr-panel px-3 sm:px-4 py-1.5 sm:py-2 rounded-full text-[11px] sm:text-sm text-nr-dim/80 max-w-[calc(100%-20px)]">
              <Loader2 className="w-4 h-4 animate-spin text-nr-accent flex-shrink-0" />{" "}
              <span className="text-center">Obtendo localização…</span>
            </div>
          )}

          {radar.state === "active" && radar.userPos && (
            <div className="absolute bottom-3 left-3 z-[400] bg-nr-panel/95 px-3 py-2 rounded-lg text-[11px] text-nr-dim/80 max-w-[calc(100%-24px)] space-y-1">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-nr-accent flex-shrink-0" />
                <span className="truncate">Local da busca · raio {config.radius} m</span>
              </div>
              <div className="font-mono text-[10px] text-nr-dim/60">
                {radar.userPos[0].toFixed(5)}, {radar.userPos[1].toFixed(5)}
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                {radar.source === "manual" ? (
                  <span className="text-nr-accent">📍 Ajustado manualmente</span>
                ) : radar.accuracy != null ? (
                  <span
                    className={
                      describeAccuracy(radar.accuracy).level === "high"
                        ? "text-emerald-400"
                        : describeAccuracy(radar.accuracy).level === "low"
                        ? "text-rose-400"
                        : "text-amber-400"
                    }
                  >
                    Precisão ±{Math.round(radar.accuracy)} m ({describeAccuracy(radar.accuracy).label})
                  </span>
                ) : (
                  <span>Precisão desconhecida</span>
                )}
                {radar.refining && (
                  <span className="flex items-center gap-1 text-nr-dim/60">
                    <Loader2 className="w-3 h-3 animate-spin" /> refinando…
                  </span>
                )}
                {!radar.refining && (radar.source === "manual" || (radar.accuracy ?? 0) > 25) && (
                  <button
                    onClick={radar.refreshLocation}
                    className="underline text-nr-accent hover:opacity-80"
                  >
                    {radar.source === "manual" ? "Usar localização do aparelho" : "Atualizar localização"}
                  </button>
                )}
              </div>
              {radar.source === "gps" && !radar.refining && (radar.accuracy ?? 0) > 50 && (
                <p className="text-[10px] text-nr-dim/50 max-w-[260px]">
                  Dica: arraste o marcador azul no mapa para o local exato.
                </p>
              )}
            </div>
          )}

          {radar.state === "active" && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 z-[400] flex items-center gap-2 bg-nr-panel px-3 sm:px-4 py-1.5 sm:py-2 rounded-full text-[11px] sm:text-sm text-nr-dim/80 max-w-[calc(100%-20px)]">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse flex-shrink-0" />
              <span className="text-center">{radarStatusText}</span>
            </div>
          )}
        </main>

        {/* Right panel — mesma fonte de dados do mapa */}
        <aside className="min-w-0 bg-nr-bg border-t lg:border-t-0 lg:border-l border-nr-border h-[60vh] md:col-span-2 md:h-[50vh] md:min-h-[360px] lg:col-span-1 lg:h-auto lg:min-h-0">
          <NetworkList
            networks={networks}
            selected={activeSelected}
            onSelect={selectNetwork}
            onAnalyze={esp32.analyzeNetwork}
            onScan={esp32.scan}
            connectionState={esp32.connectionState}
            demoMode={esp32.demoMode}
            lastUpdate={esp32.lastUpdate}
            radarActive={radar.state === "active"}
          />
        </aside>

        {activeSelected && (
          <NetworkDetail
            network={activeSelected}
            onAnalyze={() => esp32.analyzeNetwork(activeSelected.ssid)}
            onClose={() => setSelectedNetwork(null)}
          />
        )}

        <AnalysisModal analysis={esp32.analysis} onClose={() => esp32.setAnalysis(null)} />
        <OptimizeModal result={esp32.optimizeResult} onClose={() => esp32.setOptimizeResult(null)} />

        <SystemMenu open={systemOpen} onClose={() => setSystemOpen(false)} config={{ ...config, theme }} onChange={handleConfigChange} />
      </div>
    </div>
  );
}