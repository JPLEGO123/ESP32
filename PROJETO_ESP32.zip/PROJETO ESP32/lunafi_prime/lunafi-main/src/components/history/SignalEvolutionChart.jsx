import { useMemo, useState } from "react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { TrendingUp } from "lucide-react";

// Gráfico de evolução do RSSI ao longo das análises registradas no histórico.
// - Eixo X: data/hora da medição · Eixo Y: RSSI (dBm).
// - "Todas as redes" usa o melhor sinal de cada análise; ao escolher um SSID,
//   plota o RSSI daquele SSID em cada análise onde ele foi medido.
// Nunca cria valores fictícios: se não houver pontos suficientes, informa o usuário.
export default function SignalEvolutionChart({ analyses }) {
  const [ssid, setSsid] = useState("all");

  const ssids = useMemo(() => {
    const set = new Set();
    (analyses || []).forEach((a) => (a.networks || []).forEach((n) => n.ssid && set.add(n.ssid)));
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [analyses]);

  const data = useMemo(() => {
    const asc = [...(analyses || [])].sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
    return asc
      .map((a) => {
        let rssi;
        if (ssid === "all") {
          rssi = a.bestRssi;
        } else {
          const net = (a.networks || []).find((n) => n.ssid === ssid);
          rssi = net ? net.rssi : null;
        }
        if (typeof rssi !== "number") return null;
        return {
          label: new Date(a.timestamp).toLocaleString("pt-BR", {
            day: "2-digit",
            month: "2-digit",
            hour: "2-digit",
            minute: "2-digit",
          }),
          rssi,
        };
      })
      .filter(Boolean);
  }, [analyses, ssid]);

  const hasChart = data.length >= 2;

  return (
    <div className="bg-nr-panel border border-nr-border rounded-xl p-4">
      <div className="flex items-center justify-between gap-3 mb-3 flex-wrap">
        <h2 className="text-sm font-semibold flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-nr-accent" /> Evolução do sinal
        </h2>
        <select
          value={ssid}
          onChange={(e) => setSsid(e.target.value)}
          className="bg-nr-bg border border-nr-border rounded-lg px-3 py-2 text-xs text-nr-text focus:outline-none focus:border-nr-accent max-w-full"
        >
          <option value="all">Todas as redes (melhor sinal)</option>
          {ssids.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      {hasChart ? (
        <div className="h-56 w-full bg-nr-bg rounded-xl border border-nr-border p-3">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{ top: 5, right: 8, bottom: 5, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.25)" />
              <XAxis dataKey="label" tick={{ fill: "#94a3b8", fontSize: 10 }} stroke="rgba(148,163,184,0.35)" />
              <YAxis domain={[-95, -30]} tick={{ fill: "#94a3b8", fontSize: 10 }} stroke="rgba(148,163,184,0.35)" />
              <Tooltip
                contentStyle={{ background: "#1a2530", border: "1px solid #243441", borderRadius: 8, fontSize: 12 }}
                labelStyle={{ color: "#cbd5e1" }}
                formatter={(v) => [`${v} dBm`, "RSSI"]}
              />
              <Line type="monotone" dataKey="rssi" stroke="#22d3ee" strokeWidth={2} dot={{ r: 3, fill: "#22d3ee" }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <p className="text-xs text-nr-dim/50 bg-nr-bg rounded-xl border border-nr-border p-4 text-center">
          Ainda não há dados suficientes para mostrar a evolução do sinal.
        </p>
      )}
    </div>
  );
}